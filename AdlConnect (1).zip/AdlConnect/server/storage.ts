import {
  users,
  cases,
  documents,
  laws,
  courts,
  aiConversations,
  type User,
  type UpsertUser,
  type Case,
  type InsertCase,
  type Document,
  type InsertDocument,
  type Law,
  type InsertLaw,
  type Court,
  type InsertCourt,
  type AiConversation,
  type InsertAiConversation,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, ilike, and, sql, or } from "drizzle-orm";

export interface IStorage {
  // User operations - required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Case operations
  getCases(userId: string, role: string): Promise<Case[]>;
  getCase(id: string): Promise<Case | undefined>;
  createCase(caseData: InsertCase): Promise<Case>;
  updateCase(id: string, caseData: Partial<InsertCase>): Promise<Case>;
  
  // Document operations
  getDocuments(caseId?: string, isTemplate?: boolean): Promise<Document[]>;
  getDocument(id: string): Promise<Document | undefined>;
  createDocument(documentData: InsertDocument): Promise<Document>;
  updateDocument(id: string, documentData: Partial<InsertDocument>): Promise<Document>;
  
  // Law operations
  getLaws(search?: string, category?: string): Promise<Law[]>;
  getLaw(id: string): Promise<Law | undefined>;
  createLaw(lawData: InsertLaw): Promise<Law>;
  
  // Court operations
  getCourts(city?: string): Promise<Court[]>;
  getCourt(id: string): Promise<Court | undefined>;
  createCourt(courtData: InsertCourt): Promise<Court>;
  
  // AI conversation operations
  getConversations(userId: string): Promise<AiConversation[]>;
  createConversation(conversationData: InsertAiConversation): Promise<AiConversation>;
  
  // Search operations
  searchLaws(query: string): Promise<Law[]>;
  searchCases(query: string, userId: string): Promise<Case[]>;
  
  // Statistics
  getUserStats(userId: string, role: string): Promise<{
    activeCases: number;
    documents: number;
    clients: number;
    consultations: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations - required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Case operations
  async getCases(userId: string, role: string): Promise<Case[]> {
    let query = db.select().from(cases);
    
    if (role === "lawyer") {
      query = query.where(eq(cases.lawyerId, userId));
    } else if (role === "client") {
      query = query.where(eq(cases.clientId, userId));
    }
    
    return await query.orderBy(desc(cases.updatedAt));
  }

  async getCase(id: string): Promise<Case | undefined> {
    const [caseData] = await db.select().from(cases).where(eq(cases.id, id));
    return caseData;
  }

  async createCase(caseData: InsertCase): Promise<Case> {
    const [newCase] = await db.insert(cases).values(caseData).returning();
    return newCase;
  }

  async updateCase(id: string, caseData: Partial<InsertCase>): Promise<Case> {
    const [updatedCase] = await db
      .update(cases)
      .set({ ...caseData, updatedAt: new Date() })
      .where(eq(cases.id, id))
      .returning();
    return updatedCase;
  }

  // Document operations
  async getDocuments(caseId?: string, isTemplate?: boolean): Promise<Document[]> {
    let query = db.select().from(documents);
    
    const conditions = [];
    if (caseId) conditions.push(eq(documents.caseId, caseId));
    if (isTemplate !== undefined) conditions.push(eq(documents.isTemplate, isTemplate));
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(desc(documents.updatedAt));
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const [document] = await db.select().from(documents).where(eq(documents.id, id));
    return document;
  }

  async createDocument(documentData: InsertDocument): Promise<Document> {
    const [newDocument] = await db.insert(documents).values(documentData).returning();
    return newDocument;
  }

  async updateDocument(id: string, documentData: Partial<InsertDocument>): Promise<Document> {
    const [updatedDocument] = await db
      .update(documents)
      .set({ ...documentData, updatedAt: new Date() })
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  // Law operations
  async getLaws(search?: string, category?: string): Promise<Law[]> {
    let query = db.select().from(laws).where(eq(laws.isActive, true));
    
    const conditions = [];
    if (search) {
      conditions.push(
        or(
          ilike(laws.title, `%${search}%`),
          ilike(laws.content, `%${search}%`),
          sql`${laws.keywords} && ARRAY[${search}]`
        )
      );
    }
    if (category) conditions.push(eq(laws.category, category));
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(desc(laws.updatedAt));
  }

  async getLaw(id: string): Promise<Law | undefined> {
    const [law] = await db.select().from(laws).where(eq(laws.id, id));
    return law;
  }

  async createLaw(lawData: InsertLaw): Promise<Law> {
    const [newLaw] = await db.insert(laws).values(lawData).returning();
    return newLaw;
  }

  // Court operations
  async getCourts(city?: string): Promise<Court[]> {
    let query = db.select().from(courts);
    
    if (city) {
      query = query.where(eq(courts.city, city));
    }
    
    return await query.orderBy(courts.name);
  }

  async getCourt(id: string): Promise<Court | undefined> {
    const [court] = await db.select().from(courts).where(eq(courts.id, id));
    return court;
  }

  async createCourt(courtData: InsertCourt): Promise<Court> {
    const [newCourt] = await db.insert(courts).values(courtData).returning();
    return newCourt;
  }

  // AI conversation operations
  async getConversations(userId: string): Promise<AiConversation[]> {
    return await db
      .select()
      .from(aiConversations)
      .where(eq(aiConversations.userId, userId))
      .orderBy(desc(aiConversations.createdAt));
  }

  async createConversation(conversationData: InsertAiConversation): Promise<AiConversation> {
    const [newConversation] = await db
      .insert(aiConversations)
      .values(conversationData)
      .returning();
    return newConversation;
  }

  // Search operations
  async searchLaws(query: string): Promise<Law[]> {
    return await db
      .select()
      .from(laws)
      .where(
        and(
          eq(laws.isActive, true),
          or(
            ilike(laws.title, `%${query}%`),
            ilike(laws.content, `%${query}%`),
            ilike(laws.summary, `%${query}%`),
            sql`${laws.keywords} && ARRAY[${query}]`
          )
        )
      )
      .orderBy(desc(laws.updatedAt));
  }

  async searchCases(query: string, userId: string): Promise<Case[]> {
    return await db
      .select()
      .from(cases)
      .where(
        and(
          or(eq(cases.lawyerId, userId), eq(cases.clientId, userId)),
          or(
            ilike(cases.title, `%${query}%`),
            ilike(cases.description, `%${query}%`),
            ilike(cases.caseNumber, `%${query}%`)
          )
        )
      )
      .orderBy(desc(cases.updatedAt));
  }

  // Statistics
  async getUserStats(userId: string, role: string): Promise<{
    activeCases: number;
    documents: number;
    clients: number;
    consultations: number;
  }> {
    let activeCasesQuery;
    if (role === "lawyer") {
      activeCasesQuery = db
        .select({ count: sql<number>`count(*)` })
        .from(cases)
        .where(
          and(
            eq(cases.lawyerId, userId),
            or(
              eq(cases.status, "new"),
              eq(cases.status, "under_review"),
              eq(cases.status, "accepted"),
              eq(cases.status, "in_progress")
            )
          )
        );
    } else {
      activeCasesQuery = db
        .select({ count: sql<number>`count(*)` })
        .from(cases)
        .where(
          and(
            eq(cases.clientId, userId),
            or(
              eq(cases.status, "new"),
              eq(cases.status, "under_review"),
              eq(cases.status, "accepted"),
              eq(cases.status, "in_progress")
            )
          )
        );
    }

    const documentsQuery = db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(eq(documents.uploadedById, userId));

    const clientsQuery = role === "lawyer" 
      ? db
          .select({ count: sql<number>`count(DISTINCT ${cases.clientId})` })
          .from(cases)
          .where(eq(cases.lawyerId, userId))
      : db
          .select({ count: sql<number>`count(*)` })
          .from(cases)
          .where(eq(cases.clientId, userId));

    const consultationsQuery = db
      .select({ count: sql<number>`count(*)` })
      .from(aiConversations)
      .where(eq(aiConversations.userId, userId));

    const [activeCases, documentsResult, clients, consultations] = await Promise.all([
      activeCasesQuery,
      documentsQuery,
      clientsQuery,
      consultationsQuery,
    ]);

    return {
      activeCases: activeCases[0]?.count || 0,
      documents: documentsResult[0]?.count || 0,
      clients: clients[0]?.count || 0,
      consultations: consultations[0]?.count || 0,
    };
  }

  // Subscription Plans
  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.isActive, true));
  }

  async createSubscriptionPlan(planData: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    const [plan] = await db.insert(subscriptionPlans).values(planData).returning();
    return plan;
  }

  async updateSubscriptionPlan(id: string, planData: Partial<InsertSubscriptionPlan>): Promise<SubscriptionPlan> {
    const [plan] = await db
      .update(subscriptionPlans)
      .set({ ...planData, updatedAt: new Date() })
      .where(eq(subscriptionPlans.id, id))
      .returning();
    return plan;
  }

  async deleteSubscriptionPlan(id: string): Promise<void> {
    await db.delete(subscriptionPlans).where(eq(subscriptionPlans.id, id));
  }

  // Government Services
  async getGovernmentServices(): Promise<GovernmentService[]> {
    return await db.select().from(governmentServices).where(eq(governmentServices.isActive, true));
  }

  async createGovernmentService(serviceData: InsertGovernmentService): Promise<GovernmentService> {
    const [service] = await db.insert(governmentServices).values(serviceData).returning();
    return service;
  }

  async createServiceRequest(requestData: InsertServiceRequest): Promise<ServiceRequest> {
    const [request] = await db.insert(serviceRequests).values(requestData).returning();
    return request;
  }

  // Sharia Services
  async getShariaServices(): Promise<ShariaService[]> {
    return await db.select().from(shariaServices);
  }

  async createShariaService(serviceData: InsertShariaService): Promise<ShariaService> {
    const [service] = await db.insert(shariaServices).values(serviceData).returning();
    return service;
  }

  // Professional Reviews
  async createProfessionalReview(reviewData: InsertProfessionalReview): Promise<ProfessionalReview> {
    const [review] = await db.insert(professionalReviews).values(reviewData).returning();
    return review;
  }

  async getProfessionalReviews(professionalId: string): Promise<ProfessionalReview[]> {
    return await db.select().from(professionalReviews).where(eq(professionalReviews.professionalId, professionalId));
  }

  // Public API for guest browsing
  async getPublicLawyers(filters?: { city?: string; specialization?: string; search?: string }) {
    let query = db.select({
      id: users.id,
      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,
      phone: users.phone,
      specialization: users.specialization,
      licenseNumber: users.licenseNumber,
      address: users.address,
      city: users.city,
      governorate: users.governorate,
      rating: users.rating,
      reviewsCount: users.reviewsCount,
      experience: users.experience,
      isVerified: users.isVerified,
      profileImageUrl: users.profileImageUrl,
      role: users.role,
    }).from(users).where(and(
      eq(users.role, "lawyer"),
      eq(users.isActive, true),
      eq(users.isPublic, true)
    ));

    if (filters?.city) {
      query = query.where(eq(users.city, filters.city));
    }

    if (filters?.specialization) {
      query = query.where(eq(users.specialization, filters.specialization));
    }

    if (filters?.search) {
      query = query.where(
        or(
          sql`LOWER(${users.firstName} || ' ' || ${users.lastName}) LIKE LOWER('%' || ${filters.search} || '%')`,
          sql`LOWER(${users.specialization}) LIKE LOWER('%' || ${filters.search} || '%')`
        )
      );
    }

    return await query;
  }

  async getPublicLegalSecretaries(filters?: { city?: string; specialization?: string; search?: string }) {
    let query = db.select({
      id: users.id,
      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,
      phone: users.phone,
      specialization: users.specialization,
      licenseNumber: users.licenseNumber,
      address: users.address,
      city: users.city,
      governorate: users.governorate,
      rating: users.rating,
      reviewsCount: users.reviewsCount,
      experience: users.experience,
      isVerified: users.isVerified,
      profileImageUrl: users.profileImageUrl,
      role: users.role,
    }).from(users).where(and(
      eq(users.role, "legal_secretary"),
      eq(users.isActive, true),
      eq(users.isPublic, true)
    ));

    if (filters?.city) {
      query = query.where(eq(users.city, filters.city));
    }

    if (filters?.specialization) {
      query = query.where(eq(users.specialization, filters.specialization));
    }

    if (filters?.search) {
      query = query.where(
        or(
          sql`LOWER(${users.firstName} || ' ' || ${users.lastName}) LIKE LOWER('%' || ${filters.search} || '%')`,
          sql`LOWER(${users.specialization}) LIKE LOWER('%' || ${filters.search} || '%')`
        )
      );
    }

    return await query;
  }

  async getPublicStatistics() {
    const [lawyersCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(and(eq(users.role, "lawyer"), eq(users.isActive, true)));

    const [legalSecretariesCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(and(eq(users.role, "legal_secretary"), eq(users.isActive, true)));

    const [courtsCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(courts);

    return {
      totalLawyers: lawyersCount?.count || 0,
      totalLegalSecretaries: legalSecretariesCount?.count || 0,
      totalCourts: courtsCount?.count || 0,
    };
  }

  // Admin Statistics
  async getAdminStats() {
    const [totalUsers] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);

    const [activeSubscriptions] = await db
      .select({ count: sql<number>`count(*)` })
      .from(userSubscriptions)
      .where(and(
        eq(userSubscriptions.isActive, true),
        sql`${userSubscriptions.expiresAt} > NOW()`
      ));

    const [activeCases] = await db
      .select({ count: sql<number>`count(*)` })
      .from(cases)
      .where(
        or(
          eq(cases.status, "new"),
          eq(cases.status, "under_review"),
          eq(cases.status, "accepted"),
          eq(cases.status, "in_progress")
        )
      );

    // Mock revenue calculation - in real app would sum subscription payments
    const monthlyRevenue = (activeSubscriptions[0]?.count || 0) * 1000;

    return {
      totalUsers: totalUsers[0]?.count || 0,
      activeSubscriptions: activeSubscriptions[0]?.count || 0,
      activeCases: activeCases[0]?.count || 0,
      monthlyRevenue,
    };
  }

  // Student/Trainee Stats
  async getStudentStats(userId: string) {
    // Mock implementation - in real app would calculate from courses and progress tables
    return {
      completedCourses: 5,
      totalCourses: 20,
      practiceHours: 120,
      averageGrade: 85,
      certificates: 3,
    };
  }

  // Sharia Secretary Stats
  async getShariaStats(userId: string) {
    const [activeCases] = await db
      .select({ count: sql<number>`count(*)` })
      .from(cases)
      .where(and(
        eq(cases.lawyerId, userId),
        or(
          eq(cases.status, "new"),
          eq(cases.status, "under_review"),
          eq(cases.status, "accepted"),
          eq(cases.status, "in_progress")
        )
      ));

    // Mock consultations and inheritance calculations
    return {
      activeCases: activeCases[0]?.count || 0,
      consultations: 25,
      inheritanceCalculations: 12,
      monthlyRevenue: 15000,
    };
  }
}

export const storage = new DatabaseStorage();

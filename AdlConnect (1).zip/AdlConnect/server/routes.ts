import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertCaseSchema,
  insertDocumentSchema,
  insertLawSchema,
  insertCourtSchema,
  insertAiConversationSchema,
} from "@shared/schema";
import { analyzeCase, searchLegalDatabase } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const stats = await storage.getUserStats(userId, user.role);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Cases routes
  app.get('/api/cases', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const cases = await storage.getCases(userId, user.role);
      res.json(cases);
    } catch (error) {
      console.error("Error fetching cases:", error);
      res.status(500).json({ message: "Failed to fetch cases" });
    }
  });

  app.get('/api/cases/:id', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const caseData = await storage.getCase(id);
      if (!caseData) {
        return res.status(404).json({ message: "Case not found" });
      }
      res.json(caseData);
    } catch (error) {
      console.error("Error fetching case:", error);
      res.status(500).json({ message: "Failed to fetch case" });
    }
  });

  app.post('/api/cases', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const validatedData = insertCaseSchema.parse(req.body);
      
      // Set lawyer or client based on user role
      if (user.role === "lawyer") {
        validatedData.lawyerId = userId;
      } else {
        validatedData.clientId = userId;
      }

      const newCase = await storage.createCase(validatedData);
      res.status(201).json(newCase);
    } catch (error) {
      console.error("Error creating case:", error);
      res.status(500).json({ message: "Failed to create case" });
    }
  });

  app.patch('/api/cases/:id', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertCaseSchema.partial().parse(req.body);
      
      const updatedCase = await storage.updateCase(id, validatedData);
      res.json(updatedCase);
    } catch (error) {
      console.error("Error updating case:", error);
      res.status(500).json({ message: "Failed to update case" });
    }
  });

  // Documents routes
  app.get('/api/documents', isAuthenticated, async (req, res) => {
    try {
      const { caseId, isTemplate } = req.query;
      const documents = await storage.getDocuments(
        caseId as string,
        isTemplate === 'true' ? true : isTemplate === 'false' ? false : undefined
      );
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post('/api/documents', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertDocumentSchema.parse({
        ...req.body,
        uploadedById: userId,
      });
      
      const newDocument = await storage.createDocument(validatedData);
      res.status(201).json(newDocument);
    } catch (error) {
      console.error("Error creating document:", error);
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  // Laws routes
  app.get('/api/laws', async (req, res) => {
    try {
      const { search, category } = req.query;
      const laws = await storage.getLaws(search as string, category as string);
      res.json(laws);
    } catch (error) {
      console.error("Error fetching laws:", error);
      res.status(500).json({ message: "Failed to fetch laws" });
    }
  });

  app.get('/api/laws/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const law = await storage.getLaw(id);
      if (!law) {
        return res.status(404).json({ message: "Law not found" });
      }
      res.json(law);
    } catch (error) {
      console.error("Error fetching law:", error);
      res.status(500).json({ message: "Failed to fetch law" });
    }
  });

  app.post('/api/laws', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const validatedData = insertLawSchema.parse(req.body);
      const newLaw = await storage.createLaw(validatedData);
      res.status(201).json(newLaw);
    } catch (error) {
      console.error("Error creating law:", error);
      res.status(500).json({ message: "Failed to create law" });
    }
  });

  // Courts routes
  app.get('/api/courts', async (req, res) => {
    try {
      const { city } = req.query;
      const courts = await storage.getCourts(city as string);
      res.json(courts);
    } catch (error) {
      console.error("Error fetching courts:", error);
      res.status(500).json({ message: "Failed to fetch courts" });
    }
  });

  app.post('/api/courts', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const validatedData = insertCourtSchema.parse(req.body);
      const newCourt = await storage.createCourt(validatedData);
      res.status(201).json(newCourt);
    } catch (error) {
      console.error("Error creating court:", error);
      res.status(500).json({ message: "Failed to create court" });
    }
  });

  // AI Assistant routes
  app.get('/api/ai/conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversations = await storage.getConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.post('/api/ai/ask', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { question, caseContext } = req.body;

      if (!question) {
        return res.status(400).json({ message: "Question is required" });
      }

      // Use OpenAI to analyze the question and provide legal guidance
      const aiResponse = await searchLegalDatabase(question, caseContext);
      
      // Save the conversation
      const conversationData = insertAiConversationSchema.parse({
        userId,
        question,
        response: aiResponse.answer,
        context: caseContext || {},
        relatedLaws: aiResponse.relatedLaws || [],
        relatedCases: aiResponse.relatedCases || [],
      });

      const conversation = await storage.createConversation(conversationData);
      res.json({
        ...conversation,
        suggestions: aiResponse.suggestions,
        legalReferences: aiResponse.legalReferences,
      });
    } catch (error) {
      console.error("Error processing AI request:", error);
      res.status(500).json({ message: "Failed to process AI request" });
    }
  });

  app.post('/api/ai/analyze-case', isAuthenticated, async (req: any, res) => {
    try {
      const { caseDescription, caseType } = req.body;

      if (!caseDescription) {
        return res.status(400).json({ message: "Case description is required" });
      }

      const analysis = await analyzeCase(caseDescription, caseType);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing case:", error);
      res.status(500).json({ message: "Failed to analyze case" });
    }
  });

  // Search routes
  app.get('/api/search/laws', async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      
      const laws = await storage.searchLaws(q as string);
      res.json(laws);
    } catch (error) {
      console.error("Error searching laws:", error);
      res.status(500).json({ message: "Failed to search laws" });
    }
  });

  app.get('/api/search/cases', isAuthenticated, async (req: any, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      
      const userId = req.user.claims.sub;
      const cases = await storage.searchCases(q as string, userId);
      res.json(cases);
    } catch (error) {
      console.error("Error searching cases:", error);
      res.status(500).json({ message: "Failed to search cases" });
    }
  });

  // Admin Routes (Subscription Plans)
  app.get("/api/admin/subscription-plans", isAuthenticated, async (req: any, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching subscription plans:", error);
      res.status(500).json({ message: "Failed to fetch subscription plans" });
    }
  });

  app.post("/api/admin/subscription-plans", isAuthenticated, async (req: any, res) => {
    try {
      const plan = await storage.createSubscriptionPlan(req.body);
      res.status(201).json(plan);
    } catch (error) {
      console.error("Error creating subscription plan:", error);
      res.status(500).json({ message: "Failed to create subscription plan" });
    }
  });

  app.put("/api/admin/subscription-plans/:id", isAuthenticated, async (req: any, res) => {
    try {
      const plan = await storage.updateSubscriptionPlan(req.params.id, req.body);
      res.json(plan);
    } catch (error) {
      console.error("Error updating subscription plan:", error);
      res.status(500).json({ message: "Failed to update subscription plan" });
    }
  });

  app.delete("/api/admin/subscription-plans/:id", isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteSubscriptionPlan(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting subscription plan:", error);
      res.status(500).json({ message: "Failed to delete subscription plan" });
    }
  });

  app.get("/api/admin/stats", isAuthenticated, async (req: any, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin statistics" });
    }
  });

  // Government Services
  app.get("/api/government-services", isAuthenticated, async (req: any, res) => {
    try {
      const services = await storage.getGovernmentServices();
      res.json(services);
    } catch (error) {
      console.error("Error fetching government services:", error);
      res.status(500).json({ message: "Failed to fetch government services" });
    }
  });

  app.post("/api/government-services", isAuthenticated, async (req: any, res) => {
    try {
      const service = await storage.createGovernmentService(req.body);
      res.status(201).json(service);
    } catch (error) {
      console.error("Error creating government service:", error);
      res.status(500).json({ message: "Failed to create government service" });
    }
  });

  app.post("/api/service-requests", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const requestData = { ...req.body, userId };
      const request = await storage.createServiceRequest(requestData);
      res.status(201).json(request);
    } catch (error) {
      console.error("Error creating service request:", error);
      res.status(500).json({ message: "Failed to create service request" });
    }
  });

  // Sharia Services
  app.get("/api/sharia-services", isAuthenticated, async (req: any, res) => {
    try {
      const services = await storage.getShariaServices();
      res.json(services);
    } catch (error) {
      console.error("Error fetching Sharia services:", error);
      res.status(500).json({ message: "Failed to fetch Sharia services" });
    }
  });

  app.post("/api/sharia-services", isAuthenticated, async (req: any, res) => {
    try {
      const service = await storage.createShariaService(req.body);
      res.status(201).json(service);
    } catch (error) {
      console.error("Error creating Sharia service:", error);
      res.status(500).json({ message: "Failed to create Sharia service" });
    }
  });

  // Student/Trainee Stats
  app.get("/api/student/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getStudentStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching student stats:", error);
      res.status(500).json({ message: "Failed to fetch student statistics" });
    }
  });

  // Sharia Secretary Stats
  app.get("/api/sharia/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getShariaStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching Sharia stats:", error);
      res.status(500).json({ message: "Failed to fetch Sharia statistics" });
    }
  });

  // Public Routes (No authentication required)
  app.get("/api/public/lawyers", async (req, res) => {
    try {
      const { city, specialization, search } = req.query;
      const lawyers = await storage.getPublicLawyers({
        city: city as string,
        specialization: specialization as string,
        search: search as string,
      });
      res.json(lawyers);
    } catch (error) {
      console.error("Error fetching public lawyers:", error);
      res.status(500).json({ message: "Failed to fetch lawyers" });
    }
  });

  app.get("/api/public/legal-secretaries", async (req, res) => {
    try {
      const { city, specialization, search } = req.query;
      const secretaries = await storage.getPublicLegalSecretaries({
        city: city as string,
        specialization: specialization as string,
        search: search as string,
      });
      res.json(secretaries);
    } catch (error) {
      console.error("Error fetching public legal secretaries:", error);
      res.status(500).json({ message: "Failed to fetch legal secretaries" });
    }
  });

  app.get("/api/public/stats", async (req, res) => {
    try {
      const stats = await storage.getPublicStatistics();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching public stats:", error);
      res.status(500).json({ message: "Failed to fetch public statistics" });
    }
  });

  // Professional Reviews
  app.post("/api/reviews", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reviewData = { ...req.body, reviewerId: userId };
      const review = await storage.createProfessionalReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get("/api/reviews/:professionalId", async (req, res) => {
    try {
      const reviews = await storage.getProfessionalReviews(req.params.professionalId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

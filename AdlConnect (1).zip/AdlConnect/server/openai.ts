import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

export async function searchLegalDatabase(
  question: string, 
  caseContext?: any
): Promise<{
  answer: string;
  relatedLaws: string[];
  relatedCases: string[];
  suggestions: string[];
  legalReferences: string[];
}> {
  try {
    const contextPrompt = caseContext 
      ? `Context about the case: ${JSON.stringify(caseContext, null, 2)}\n\n`
      : "";

    const prompt = `${contextPrompt}Legal Question: ${question}

As a Yemeni legal expert AI assistant, please provide a comprehensive answer to this legal question. 

Please respond in Arabic and include:
1. A detailed legal analysis
2. Relevant Yemeni laws and regulations that apply
3. Practical legal advice and next steps
4. Any potential legal risks or considerations
5. Suggested legal procedures or documentation needed

Respond with JSON in this exact format:
{
  "answer": "detailed legal answer in Arabic",
  "relatedLaws": ["array of relevant Yemeni law names/numbers"],
  "relatedCases": ["array of similar case types"],
  "suggestions": ["array of practical next steps"],
  "legalReferences": ["array of specific legal articles or regulations"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert in Yemeni law and legal procedures. Provide accurate, helpful legal guidance in Arabic. Always format your response as valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      answer: result.answer || "عذراً، لم أتمكن من تحليل السؤال القانوني.",
      relatedLaws: result.relatedLaws || [],
      relatedCases: result.relatedCases || [],
      suggestions: result.suggestions || [],
      legalReferences: result.legalReferences || [],
    };
  } catch (error) {
    console.error("Error in searchLegalDatabase:", error);
    throw new Error("Failed to analyze legal question");
  }
}

export async function analyzeCase(
  caseDescription: string, 
  caseType?: string
): Promise<{
  analysis: string;
  recommendedActions: string[];
  legalStrategy: string;
  requiredDocuments: string[];
  estimatedTimeline: string;
  potentialOutcomes: string[];
}> {
  try {
    const prompt = `Case Type: ${caseType || "غير محدد"}
Case Description: ${caseDescription}

As a Yemeni legal expert, please analyze this case and provide:

1. Detailed legal analysis of the case
2. Recommended legal actions and strategy
3. Required documents and evidence
4. Estimated timeline for resolution
5. Potential legal outcomes
6. Risks and considerations

Please respond in Arabic with JSON format:
{
  "analysis": "detailed case analysis in Arabic",
  "recommendedActions": ["array of recommended actions"],
  "legalStrategy": "overall legal strategy",
  "requiredDocuments": ["array of required documents"],
  "estimatedTimeline": "estimated timeline for case resolution",
  "potentialOutcomes": ["array of potential case outcomes"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert Yemeni lawyer specializing in case analysis and legal strategy. Provide detailed, actionable legal guidance in Arabic."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      analysis: result.analysis || "لم يتم تحليل القضية.",
      recommendedActions: result.recommendedActions || [],
      legalStrategy: result.legalStrategy || "لم يتم تحديد استراتيجية قانونية.",
      requiredDocuments: result.requiredDocuments || [],
      estimatedTimeline: result.estimatedTimeline || "غير محدد",
      potentialOutcomes: result.potentialOutcomes || [],
    };
  } catch (error) {
    console.error("Error in analyzeCase:", error);
    throw new Error("Failed to analyze case");
  }
}

export async function generateLegalDocument(
  documentType: string,
  details: any
): Promise<{
  content: string;
  title: string;
  suggestedChanges: string[];
}> {
  try {
    const prompt = `Document Type: ${documentType}
Details: ${JSON.stringify(details, null, 2)}

Please generate a professional legal document in Arabic for Yemeni law. 

Respond with JSON:
{
  "content": "complete document content in Arabic",
  "title": "document title",
  "suggestedChanges": ["array of suggested modifications or additions"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert legal document writer specializing in Yemeni law. Generate professional, legally sound documents in Arabic."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      content: result.content || "لم يتم إنشاء المستند.",
      title: result.title || "مستند قانوني",
      suggestedChanges: result.suggestedChanges || [],
    };
  } catch (error) {
    console.error("Error in generateLegalDocument:", error);
    throw new Error("Failed to generate legal document");
  }
}

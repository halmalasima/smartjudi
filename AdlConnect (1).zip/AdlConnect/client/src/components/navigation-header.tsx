import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function NavigationHeader() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      // TODO: Implement search functionality
      console.log('Search for:', searchQuery);
    }
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getUserRoleLabel = (role: string) => {
    const roleMap = {
      lawyer: "محامي معتمد",
      legal_secretary: "سكرتير قانوني",
      client: "عميل",
      trainee: "متدرب",
      admin: "مدير النظام"
    };
    return roleMap[role as keyof typeof roleMap] || "مستخدم";
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Title */}
          <div className="flex items-center space-x-reverse space-x-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-600 to-secondary-600 rounded-lg flex items-center justify-center ml-3">
                <i className="fas fa-balance-scale text-white text-lg"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">منصة القضاء الذكي</h1>
                <p className="text-sm text-gray-500">النظام المتكامل للخدمات القانونية</p>
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-lg mx-8">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="البحث في القوانين والأحكام..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyUp={handleSearch}
                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
              <i className="fas fa-search absolute right-3 top-3 text-gray-400"></i>
            </div>
          </div>

          {/* User Profile */}
          <div className="flex items-center space-x-reverse space-x-4">
            <Button variant="ghost" size="sm" className="relative p-2 text-gray-400 hover:text-gray-500">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -left-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">3</span>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-reverse space-x-3 hover:bg-gray-50">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user?.profileImageUrl || ""} alt="صورة المستخدم" />
                    <AvatarFallback>
                      {user?.firstName?.charAt(0) || user?.lastName?.charAt(0) || "م"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block text-right">
                    <p className="text-sm font-medium text-gray-900">
                      {user?.firstName} {user?.lastName}
                    </p>
                    <p className="text-xs text-gray-500">
                      {getUserRoleLabel(user?.role || "")}
                    </p>
                  </div>
                  <i className="fas fa-chevron-down text-gray-400 text-sm"></i>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>حسابي</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <i className="fas fa-user ml-2"></i>
                  الملف الشخصي
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <i className="fas fa-cog ml-2"></i>
                  الإعدادات
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <i className="fas fa-question-circle ml-2"></i>
                  الدعم الفني
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <i className="fas fa-sign-out-alt ml-2"></i>
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </nav>
  );
}

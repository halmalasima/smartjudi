import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function Sidebar() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();

  const isActive = (path: string) => location === path;

  const getUserRoleLabel = (role: string) => {
    const roleMap = {
      lawyer: "محامي معتمد",
      legal_secretary: "سكرتير قانوني",
      client: "عميل",
      trainee: "متدرب",
      admin: "مدير النظام"
    };
    return roleMap[role as keyof typeof roleMap] || "مستخدم";
  };

  const getUserRoleIcon = (role: string) => {
    const iconMap = {
      lawyer: "fa-user-tie",
      legal_secretary: "fa-user-edit",
      client: "fa-user",
      trainee: "fa-user-graduate",
      admin: "fa-user-shield"
    };
    return iconMap[role as keyof typeof iconMap] || "fa-user";
  };

  const menuItems = [
    { path: "/", icon: "fa-tachometer-alt", label: "لوحة التحكم" },
    { path: "/cases", icon: "fa-gavel", label: "إدارة القضايا" },
    { path: "/laws", icon: "fa-book", label: "قاعدة القوانين" },
    { path: "/templates", icon: "fa-file-contract", label: "نماذج الدعاوى" },
    { path: "/documents", icon: "fa-folder", label: "أرشيف الوثائق" },
    { path: "/lawyers", icon: "fa-users", label: "دليل المحامين" },
    { path: "/courts", icon: "fa-building", label: "دليل المحاكم" },
    { path: "/ai-assistant", icon: "fa-robot", label: "المساعد الذكي" },
  ];

  const supportItems = [
    { path: "/support", icon: "fa-question-circle", label: "الدعم الفني" },
    { path: "/settings", icon: "fa-cog", label: "الإعدادات" },
  ];

  return (
    <aside className="w-64 bg-white shadow-sm h-screen sticky top-16 overflow-y-auto sidebar-transition">
      <div className="p-4">
        {/* User Role Indicator */}
        <div className="bg-primary-50 rounded-lg p-3 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary-800">نوع الحساب</p>
              <p className="text-xs text-primary-600">{getUserRoleLabel(user?.role || "")}</p>
            </div>
            <div className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
              <i className={`fas ${getUserRoleIcon(user?.role || "")} text-white text-sm`}></i>
            </div>
          </div>
        </div>

        {/* Main Navigation */}
        <nav className="space-y-2">
          {menuItems.map((item) => (
            <Button
              key={item.path}
              variant="ghost"
              onClick={() => navigate(item.path)}
              className={`w-full justify-start text-right ${
                isActive(item.path)
                  ? "text-primary-700 bg-primary-50"
                  : "text-gray-600 hover:bg-gray-50"
              } hover-lift`}
            >
              <i className={`fas ${item.icon} ml-3 text-lg`}></i>
              <span className="font-medium">{item.label}</span>
            </Button>
          ))}
        </nav>

        {/* Support Section */}
        <div className="mt-8 pt-4 border-t border-gray-200">
          {supportItems.map((item) => (
            <Button
              key={item.path}
              variant="ghost"
              onClick={() => navigate(item.path)}
              className={`w-full justify-start text-right ${
                isActive(item.path)
                  ? "text-primary-700 bg-primary-50"
                  : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              <i className={`fas ${item.icon} ml-3 text-lg`}></i>
              <span>{item.label}</span>
            </Button>
          ))}
        </div>
      </div>
    </aside>
  );
}

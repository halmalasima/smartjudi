import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import CaseManagement from "@/pages/case-management";
import LegalDatabase from "@/pages/legal-database";
import DocumentTemplates from "@/pages/document-templates";
import AiAssistant from "@/pages/ai-assistant";
import ShariaSecretary from "@/pages/sharia-secretary";
import StudentTrainee from "@/pages/student-trainee";
import AdminDashboard from "@/pages/admin-dashboard";
import GuestBrowse from "@/pages/guest-browse";

function Router() {
  const { user, isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/browse" component={GuestBrowse} />
      
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          {/* Role-based routing */}
          {user?.role === "admin" ? (
            <>
              <Route path="/" component={AdminDashboard} />
              <Route path="/admin" component={AdminDashboard} />
              <Route path="/cases" component={CaseManagement} />
              <Route path="/laws" component={LegalDatabase} />
              <Route path="/templates" component={DocumentTemplates} />
              <Route path="/ai-assistant" component={AiAssistant} />
            </>
          ) : user?.role === "legal_secretary" ? (
            <>
              <Route path="/" component={ShariaSecretary} />
              <Route path="/sharia" component={ShariaSecretary} />
              <Route path="/cases" component={CaseManagement} />
              <Route path="/laws" component={LegalDatabase} />
              <Route path="/templates" component={DocumentTemplates} />
              <Route path="/ai-assistant" component={AiAssistant} />
            </>
          ) : user?.role === "trainee" ? (
            <>
              <Route path="/" component={StudentTrainee} />
              <Route path="/student" component={StudentTrainee} />
              <Route path="/laws" component={LegalDatabase} />
              <Route path="/ai-assistant" component={AiAssistant} />
            </>
          ) : (
            // Default routes for lawyers and clients
            <>
              <Route path="/" component={Dashboard} />
              <Route path="/cases" component={CaseManagement} />
              <Route path="/laws" component={LegalDatabase} />
              <Route path="/templates" component={DocumentTemplates} />
              <Route path="/ai-assistant" component={AiAssistant} />
            </>
          )}
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div dir="rtl" lang="ar" className="min-h-screen bg-gray-50">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

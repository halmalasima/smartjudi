import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Search, 
  MapPin, 
  Star, 
  Phone, 
  Mail, 
  Clock, 
  Filter,
  Scale,
  Heart,
  Home,
  Building,
  User,
  Calendar,
  Award,
  Briefcase,
  MessageCircle,
  Eye,
  Users,
  FileText,
  GraduationCap,
  CheckCircle
} from "lucide-react";

interface Professional {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  specialization: string;
  licenseNumber: string;
  address: string;
  city: string;
  governorate: string;
  rating: number;
  reviewsCount: number;
  experience: number;
  isVerified: boolean;
  profileImageUrl?: string;
  role: "lawyer" | "legal_secretary";
}

export default function GuestBrowse() {
  const [selectedTab, setSelectedTab] = useState("lawyers");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedSpecialization, setSelectedSpecialization] = useState("");
  const [sortBy, setSortBy] = useState("rating");

  // Fetch professionals
  const { data: lawyers } = useQuery({
    queryKey: ["/api/public/lawyers", { search: searchTerm, city: selectedCity, specialization: selectedSpecialization, sort: sortBy }],
  });

  const { data: legalSecretaries } = useQuery({
    queryKey: ["/api/public/legal-secretaries", { search: searchTerm, city: selectedCity, specialization: selectedSpecialization, sort: sortBy }],
  });

  const { data: courts } = useQuery({
    queryKey: ["/api/public/courts"],
  });

  const { data: statistics } = useQuery({
    queryKey: ["/api/public/statistics"],
  });

  const yemeniGovernorates = [
    "صنعاء", "عدن", "تعز", "الحديدة", "إب", "ذمار", "حضرموت", "أبين", "لحج", "البيضاء",
    "المحويت", "حجة", "صعدة", "الجوف", "مأرب", "شبوة", "المهرة", "عمران", "الضالع", "ريمة"
  ];

  const lawyerSpecializations = [
    "القانون المدني",
    "القانون التجاري",
    "القانون الجنائي",
    "قانون الأحوال الشخصية",
    "القانون الإداري",
    "قانون العمل",
    "القانون الدولي",
    "قانون الاستثمار",
    "قانون البيئة",
    "قانون الملكية الفكرية"
  ];

  const shariaSpecializations = [
    "فقه المعاملات",
    "فقه الأسرة",
    "فقه المواريث",
    "فقه العبادات",
    "الأوقاف",
    "التحكيم الشرعي",
    "الاستشارات الشرعية",
    "تصحيح العقود",
    "القضاء الشرعي"
  ];

  const filteredProfessionals = (professionals: Professional[] = []) => {
    return professionals.filter(prof => {
      const matchesSearch = !searchTerm || 
        `${prof.firstName} ${prof.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prof.specialization.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCity = !selectedCity || prof.city === selectedCity;
      const matchesSpecialization = !selectedSpecialization || prof.specialization === selectedSpecialization;
      
      return matchesSearch && matchesCity && matchesSpecialization;
    });
  };

  const ProfessionalCard = ({ professional }: { professional: Professional }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-blue-200 rounded-full flex items-center justify-center">
            {professional.profileImageUrl ? (
              <img 
                src={professional.profileImageUrl} 
                alt={`${professional.firstName} ${professional.lastName}`}
                className="w-16 h-16 rounded-full object-cover"
              />
            ) : (
              <User className="h-8 w-8 text-blue-600" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <CardTitle className="text-lg">
                {professional.firstName} {professional.lastName}
              </CardTitle>
              {professional.isVerified && (
                <CheckCircle className="h-5 w-5 text-emerald-600" />
              )}
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
              {professional.specialization}
            </p>
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500 fill-current" />
                <span>{professional.rating}</span>
                <span>({professional.reviewsCount} تقييم)</span>
              </div>
              <div className="flex items-center gap-1">
                <Award className="h-4 w-4" />
                <span>{professional.experience} سنوات خبرة</span>
              </div>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="h-4 w-4 text-gray-500" />
            <span>{professional.address}, {professional.city}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <Phone className="h-4 w-4 text-gray-500" />
            <span>{professional.phone}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <Briefcase className="h-4 w-4 text-gray-500" />
            <span>رخصة رقم: {professional.licenseNumber}</span>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" size="sm" className="flex-1">
              <Eye className="h-4 w-4 ml-1" />
              عرض الملف
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              <MessageCircle className="h-4 w-4 ml-1" />
              تواصل
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 p-4" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-blue-800 dark:text-blue-200 mb-2">
            دليل المحامين والأمناء الشرعيين في اليمن
          </h1>
          <p className="text-blue-600 dark:text-blue-400 text-lg">
            ابحث عن أفضل المحامين والأمناء الشرعيين المعتمدين في جميع أنحاء اليمن
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6 text-center">
              <Scale className="h-8 w-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">{statistics?.totalLawyers || 0}</div>
              <div className="text-sm opacity-90">محامي معتمد</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
            <CardContent className="p-6 text-center">
              <Heart className="h-8 w-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">{statistics?.totalLegalSecretaries || 0}</div>
              <div className="text-sm opacity-90">أمين شرعي</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white">
            <CardContent className="p-6 text-center">
              <Building className="h-8 w-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">{statistics?.totalCourts || 0}</div>
              <div className="text-sm opacity-90">محكمة</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6 text-center">
              <MapPin className="h-8 w-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">20</div>
              <div className="text-sm opacity-90">محافظة</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="البحث بالاسم أو التخصص..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>

              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر المحافظة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع المحافظات</SelectItem>
                  {yemeniGovernorates.map((gov) => (
                    <SelectItem key={gov} value={gov}>
                      {gov}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedSpecialization} onValueChange={setSelectedSpecialization}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر التخصص" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">جميع التخصصات</SelectItem>
                  {selectedTab === "lawyers" 
                    ? lawyerSpecializations.map((spec) => (
                        <SelectItem key={spec} value={spec}>
                          {spec}
                        </SelectItem>
                      ))
                    : shariaSpecializations.map((spec) => (
                        <SelectItem key={spec} value={spec}>
                          {spec}
                        </SelectItem>
                      ))
                  }
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="ترتيب حسب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">التقييم</SelectItem>
                  <SelectItem value="experience">سنوات الخبرة</SelectItem>
                  <SelectItem value="name">الاسم</SelectItem>
                  <SelectItem value="city">المدينة</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-white/50 dark:bg-gray-800/50">
            <TabsTrigger value="lawyers" className="flex items-center gap-2">
              <Scale className="h-4 w-4" />
              المحامون ({lawyers?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="legal_secretaries" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              الأمناء الشرعيون ({legalSecretaries?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="courts" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              المحاكم ({courts?.length || 0})
            </TabsTrigger>
          </TabsList>

          {/* Lawyers Tab */}
          <TabsContent value="lawyers" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProfessionals(lawyers)?.length > 0 ? (
                filteredProfessionals(lawyers).map((lawyer) => (
                  <ProfessionalCard key={lawyer.id} professional={lawyer} />
                ))
              ) : (
                <div className="col-span-full">
                  <Card>
                    <CardContent className="text-center py-12">
                      <Scale className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                        لم يتم العثور على محامين
                      </h3>
                      <p className="text-gray-500 mb-4">
                        جرب تغيير معايير البحث أو الفلترة
                      </p>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSearchTerm("");
                          setSelectedCity("");
                          setSelectedSpecialization("");
                        }}
                      >
                        إعادة تعيين الفلاتر
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Legal Secretaries Tab */}
          <TabsContent value="legal_secretaries" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProfessionals(legalSecretaries)?.length > 0 ? (
                filteredProfessionals(legalSecretaries).map((secretary) => (
                  <ProfessionalCard key={secretary.id} professional={secretary} />
                ))
              ) : (
                <div className="col-span-full">
                  <Card>
                    <CardContent className="text-center py-12">
                      <Heart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                        لم يتم العثور على أمناء شرعيين
                      </h3>
                      <p className="text-gray-500 mb-4">
                        جرب تغيير معايير البحث أو الفلترة
                      </p>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSearchTerm("");
                          setSelectedCity("");
                          setSelectedSpecialization("");
                        }}
                      >
                        إعادة تعيين الفلاتر
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Courts Tab */}
          <TabsContent value="courts" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {courts?.length > 0 ? (
                courts.map((court: any) => (
                  <Card key={court.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-amber-100 to-amber-200 rounded-full flex items-center justify-center">
                          <Building className="h-6 w-6 text-amber-600" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{court.name}</CardTitle>
                          <Badge variant="outline" className="mt-1">
                            {court.type}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span>{court.address}, {court.city}</span>
                        </div>
                        
                        {court.phone && (
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="h-4 w-4 text-gray-500" />
                            <span>{court.phone}</span>
                          </div>
                        )}
                        
                        {court.email && (
                          <div className="flex items-center gap-2 text-sm">
                            <Mail className="h-4 w-4 text-gray-500" />
                            <span>{court.email}</span>
                          </div>
                        )}

                        <div className="flex gap-2 pt-2">
                          <Button variant="outline" size="sm" className="flex-1">
                            <Eye className="h-4 w-4 ml-1" />
                            عرض التفاصيل
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1">
                            <Calendar className="h-4 w-4 ml-1" />
                            الجلسات
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-full">
                  <Card>
                    <CardContent className="text-center py-12">
                      <Building className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                        لا توجد محاكم مسجلة
                      </h3>
                      <p className="text-gray-500">
                        سيتم إضافة دليل المحاكم قريباً
                      </p>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Call to Action */}
        <Card className="mt-12 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">
              هل أنت محامي أو أمين شرعي؟
            </h2>
            <p className="text-lg mb-6 opacity-90">
              انضم إلى منصتنا وابدأ في تقديم خدماتك المهنية للعملاء في جميع أنحاء اليمن
            </p>
            <div className="flex gap-4 justify-center">
              <Button variant="secondary" size="lg">
                <GraduationCap className="h-5 w-5 ml-2" />
                التسجيل كمحامي
              </Button>
              <Button variant="secondary" size="lg">
                <Heart className="h-5 w-5 ml-2" />
                التسجيل كأمين شرعي
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
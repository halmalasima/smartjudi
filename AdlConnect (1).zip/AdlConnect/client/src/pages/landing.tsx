import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-reverse space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-600 to-secondary-600 rounded-lg flex items-center justify-center ml-3">
                <i className="fas fa-balance-scale text-white text-lg"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">منصة القضاء الذكي</h1>
                <p className="text-sm text-gray-500">النظام المتكامل للخدمات القانونية</p>
              </div>
            </div>
            <Button onClick={handleLogin} className="bg-primary-600 hover:bg-primary-700">
              <i className="fas fa-sign-in-alt ml-2"></i>
              تسجيل الدخول
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <Badge variant="outline" className="mb-6 text-primary-700 border-primary-200">
            منصة متقدمة مدعومة بالذكاء الاصطناعي
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            مرحباً بك في
            <span className="block text-primary-600">منصة القضاء الذكي</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            منصة شاملة لرقمنة الخدمات القانونية في اليمن. إدارة القضايا، البحث في القوانين، 
            وصياغة الوثائق القانونية بمساعدة الذكاء الاصطناعي.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button onClick={handleLogin} size="lg" className="bg-primary-600 hover:bg-primary-700">
              <i className="fas fa-rocket ml-2"></i>
              ابدأ الآن
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => window.location.href = "/browse"}
            >
              <i className="fas fa-search ml-2"></i>
              تصفح المحامين والأمناء
            </Button>
          </div>
        </div>
      </section>

      {/* User Roles Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              خدمات متخصصة للجميع
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              منصة موحدة تخدم جميع أطراف النظام القانوني في اليمن
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="hover-lift border-0 shadow-lg text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-balance-scale text-blue-600 text-2xl"></i>
                </div>
                <CardTitle className="text-blue-800">المحامون</CardTitle>
                <CardDescription>
                  إدارة شاملة للقضايا والعملاء مع أدوات متقدمة للبحث والمرافعة
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-heart text-emerald-600 text-2xl"></i>
                </div>
                <CardTitle className="text-emerald-800">الأمناء الشرعيون</CardTitle>
                <CardDescription>
                  أدوات متخصصة للمعاملات الشرعية والمواريث والاستشارات الدينية
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-graduation-cap text-purple-600 text-2xl"></i>
                </div>
                <CardTitle className="text-purple-800">الطلاب والمتدربون</CardTitle>
                <CardDescription>
                  منصة تعليمية للطلاب مع فرص التدريب العملي والمواد التعليمية
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-users text-amber-600 text-2xl"></i>
                </div>
                <CardTitle className="text-amber-800">العملاء</CardTitle>
                <CardDescription>
                  وصول سهل للخدمات القانونية وتتبع القضايا والتواصل مع المحامين
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              ميزات المنصة
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              حلول متكاملة للمهنيين القانونيين والعملاء في اليمن
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-gavel text-primary-600 text-xl"></i>
                </div>
                <CardTitle>إدارة القضايا</CardTitle>
                <CardDescription>
                  نظام متطور لإدارة القضايا القانونية مع تتبع شامل لجميع المراحل
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-secondary-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-book text-secondary-600 text-xl"></i>
                </div>
                <CardTitle>قاعدة القوانين</CardTitle>
                <CardDescription>
                  مكتبة شاملة للقوانين واللوائح اليمنية مع إمكانية البحث المتقدم
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-robot text-purple-600 text-xl"></i>
                </div>
                <CardTitle>المساعد الذكي</CardTitle>
                <CardDescription>
                  مساعد قانوني مدعوم بالذكاء الاصطناعي للاستشارات والتحليل
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-file-contract text-orange-600 text-xl"></i>
                </div>
                <CardTitle>نماذج الوثائق</CardTitle>
                <CardDescription>
                  مجموعة متنوعة من نماذج العقود والدعاوى القضائية القابلة للتعديل
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-folder text-green-600 text-xl"></i>
                </div>
                <CardTitle>أرشيف الوثائق</CardTitle>
                <CardDescription>
                  نظام آمن لحفظ وأرشفة الوثائق القانونية مع النسخ الاحتياطي
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-users text-blue-600 text-xl"></i>
                </div>
                <CardTitle>دليل المحامين</CardTitle>
                <CardDescription>
                  دليل شامل للمحامين والمحاكم والسكرتارية القانونية في اليمن
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* User Types Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              من يمكنه استخدام المنصة؟
            </h2>
            <p className="text-xl text-gray-600">
              منصة شاملة تخدم جميع أطراف النظام القانوني
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-user-tie text-primary-600 text-2xl"></i>
                </div>
                <CardTitle>المحامون</CardTitle>
                <CardDescription>
                  إدارة القضايا والعملاء والوثائق القانونية
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-user-edit text-secondary-600 text-2xl"></i>
                </div>
                <CardTitle>السكرتارية القانونية</CardTitle>
                <CardDescription>
                  مساعدة المحامين في إدارة الأعمال القانونية
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-user text-orange-600 text-2xl"></i>
                </div>
                <CardTitle>العملاء</CardTitle>
                <CardDescription>
                  البحث عن الخدمات القانونية ومتابعة القضايا
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover-lift border-0 shadow-lg">
              <CardHeader>
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-user-graduate text-purple-600 text-2xl"></i>
                </div>
                <CardTitle>المتدربون</CardTitle>
                <CardDescription>
                  التعلم والتدريب في مجال القانون
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            ابدأ رحلتك القانونية الذكية اليوم
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            انضم إلى آلاف المهنيين القانونيين الذين يثقون في منصتنا لإدارة أعمالهم القانونية
          </p>
          <Button 
            onClick={handleLogin} 
            size="lg" 
            className="bg-white text-primary-700 hover:bg-blue-50"
          >
            <i className="fas fa-sign-in-alt ml-2"></i>
            سجل دخولك الآن
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-reverse space-x-4 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-600 to-secondary-600 rounded-lg flex items-center justify-center ml-3">
                <i className="fas fa-balance-scale text-white text-lg"></i>
              </div>
              <h3 className="text-xl font-bold">منصة القضاء الذكي</h3>
            </div>
            <p className="text-gray-400 mb-4">
              منصة متكاملة لرقمنة الخدمات القانونية في اليمن
            </p>
            <p className="text-gray-500 text-sm">
              © 2024 منصة القضاء الذكي. جميع الحقوق محفوظة.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Scale, 
  Users, 
  FileText, 
  Calculator, 
  Heart, 
  Home, 
  Coins, 
  Calendar,
  Clock,
  Star,
  Search,
  Plus,
  Eye
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const shariaServiceSchema = z.object({
  name: z.string().min(1, "اسم الخدمة مطلوب"),
  description: z.string().min(1, "وصف الخدمة مطلوب"),
  category: z.string().min(1, "فئة الخدمة مطلوبة"),
  requiredDocuments: z.array(z.string()).optional(),
  estimatedDuration: z.string().min(1, "المدة المتوقعة مطلوبة"),
  fees: z.number().min(0, "الرسوم يجب أن تكون رقم موجب"),
});

type ShariaServiceForm = z.infer<typeof shariaServiceSchema>;

const caseSchema = z.object({
  title: z.string().min(1, "عنوان القضية مطلوب"),
  description: z.string().min(1, "وصف القضية مطلوب"),
  caseType: z.string().min(1, "نوع القضية مطلوب"),
  clientId: z.string().min(1, "العميل مطلوب"),
  priority: z.string().default("medium"),
  estimatedValue: z.number().optional(),
  notes: z.string().optional(),
});

type CaseForm = z.infer<typeof caseSchema>;

export default function ShariaSecretary() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedTab, setSelectedTab] = useState("dashboard");
  const [searchTerm, setSearchTerm] = useState("");

  // Dashboard statistics
  const { data: stats } = useQuery({
    queryKey: ["/api/sharia/stats"],
  });

  // Sharia services
  const { data: services } = useQuery({
    queryKey: ["/api/sharia/services"],
  });

  // Active cases
  const { data: activeCases } = useQuery({
    queryKey: ["/api/cases", { type: "sharia" }],
  });

  // Recent consultations
  const { data: consultations } = useQuery({
    queryKey: ["/api/sharia/consultations"],
  });

  // Inheritance calculations
  const { data: inheritanceCalculations } = useQuery({
    queryKey: ["/api/sharia/inheritance"],
  });

  // Forms
  const serviceForm = useForm<ShariaServiceForm>({
    resolver: zodResolver(shariaServiceSchema),
    defaultValues: {
      name: "",
      description: "",
      category: "",
      requiredDocuments: [],
      estimatedDuration: "",
      fees: 0,
    },
  });

  const caseForm = useForm<CaseForm>({
    resolver: zodResolver(caseSchema),
    defaultValues: {
      title: "",
      description: "",
      caseType: "",
      clientId: "",
      priority: "medium",
      estimatedValue: 0,
      notes: "",
    },
  });

  // Mutations
  const createServiceMutation = useMutation({
    mutationFn: (data: ShariaServiceForm) => apiRequest("/api/sharia/services", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sharia/services"] });
      serviceForm.reset();
    },
  });

  const createCaseMutation = useMutation({
    mutationFn: (data: CaseForm) => apiRequest("/api/cases", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cases"] });
      caseForm.reset();
    },
  });

  const onSubmitService = (data: ShariaServiceForm) => {
    createServiceMutation.mutate(data);
  };

  const onSubmitCase = (data: CaseForm) => {
    createCaseMutation.mutate(data);
  };

  const serviceCategories = [
    { value: "inheritance", label: "المواريث والتركات", icon: Home },
    { value: "marriage", label: "الزواج والطلاق", icon: Heart },
    { value: "financial", label: "المعاملات المالية", icon: Coins },
    { value: "waqf", label: "الأوقاف", icon: Scale },
    { value: "commercial", label: "التجارة الشرعية", icon: Calculator },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-gray-900 dark:to-gray-800 p-4" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-emerald-800 dark:text-emerald-200 mb-2">
            منصة الأمين الشرعي
          </h1>
          <p className="text-emerald-600 dark:text-emerald-400 text-lg">
            إدارة شاملة للخدمات الشرعية والمعاملات الإسلامية
          </p>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-white/50 dark:bg-gray-800/50">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <Scale className="h-4 w-4" />
              لوحة التحكم
            </TabsTrigger>
            <TabsTrigger value="services" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              الخدمات الشرعية
            </TabsTrigger>
            <TabsTrigger value="cases" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              القضايا
            </TabsTrigger>
            <TabsTrigger value="inheritance" className="flex items-center gap-2">
              <Calculator className="h-4 w-4" />
              حاسبة المواريث
            </TabsTrigger>
            <TabsTrigger value="consultations" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              الاستشارات
            </TabsTrigger>
            <TabsTrigger value="documents" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              المستندات
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">القضايا النشطة</CardTitle>
                  <Scale className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.activeCases || 0}</div>
                  <p className="text-xs opacity-80">+12% من الشهر الماضي</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الاستشارات</CardTitle>
                  <Heart className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.consultations || 0}</div>
                  <p className="text-xs opacity-80">+8% من الشهر الماضي</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-amber-500 to-orange-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">حسابات المواريث</CardTitle>
                  <Calculator className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.inheritanceCalculations || 0}</div>
                  <p className="text-xs opacity-80">+25% من الشهر الماضي</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500 to-pink-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الإيرادات الشهرية</CardTitle>
                  <Coins className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.monthlyRevenue || 0} ر.ي</div>
                  <p className="text-xs opacity-80">+18% من الشهر الماضي</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activities */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    القضايا الأخيرة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activeCases?.length > 0 ? (
                      activeCases.slice(0, 5).map((case_: any) => (
                        <div key={case_.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div>
                            <h4 className="font-medium">{case_.title}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{case_.caseType}</p>
                          </div>
                          <Badge variant={case_.priority === "high" ? "destructive" : "secondary"}>
                            {case_.status}
                          </Badge>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center">لا توجد قضايا نشطة</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5" />
                    الاستشارات الأخيرة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {consultations?.length > 0 ? (
                      consultations.slice(0, 5).map((consultation: any) => (
                        <div key={consultation.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div>
                            <h4 className="font-medium">{consultation.subject}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{consultation.clientName}</p>
                          </div>
                          <Badge variant="outline">
                            {consultation.status}
                          </Badge>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center">لا توجد استشارات حديثة</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="البحث في الخدمات..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pr-10 w-80"
                  />
                </div>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة خدمة جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>إضافة خدمة شرعية جديدة</DialogTitle>
                  </DialogHeader>
                  <Form {...serviceForm}>
                    <form onSubmit={serviceForm.handleSubmit(onSubmitService)} className="space-y-4">
                      <FormField
                        control={serviceForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>اسم الخدمة</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: استشارة مواريث" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={serviceForm.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>فئة الخدمة</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر فئة الخدمة" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {serviceCategories.map((category) => (
                                  <SelectItem key={category.value} value={category.value}>
                                    {category.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={serviceForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف الخدمة</FormLabel>
                            <FormControl>
                              <Textarea placeholder="وصف تفصيلي للخدمة..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={serviceForm.control}
                          name="estimatedDuration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>المدة المتوقعة</FormLabel>
                              <FormControl>
                                <Input placeholder="مثال: 3 أيام" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={serviceForm.control}
                          name="fees"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>الرسوم (ر.ي)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="0"
                                  {...field}
                                  onChange={(e) => field.onChange(Number(e.target.value))}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <Button 
                        type="submit" 
                        className="w-full bg-emerald-600 hover:bg-emerald-700"
                        disabled={createServiceMutation.isPending}
                      >
                        {createServiceMutation.isPending ? "جاري الحفظ..." : "حفظ الخدمة"}
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {serviceCategories.map((category) => {
                const categoryServices = services?.filter((service: any) => 
                  service.category === category.value &&
                  service.name.toLowerCase().includes(searchTerm.toLowerCase())
                ) || [];

                return (
                  <Card key={category.value} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <category.icon className="h-5 w-5" />
                        {category.label}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {categoryServices.length > 0 ? (
                          categoryServices.map((service: any) => (
                            <div key={service.id} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                              <div className="flex justify-between items-start mb-2">
                                <h4 className="font-medium">{service.name}</h4>
                                <Badge variant="outline">{service.fees} ر.ي</Badge>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                                {service.description}
                              </p>
                              <div className="flex items-center gap-2 text-xs text-gray-500">
                                <Clock className="h-3 w-3" />
                                {service.estimatedDuration}
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-gray-500 text-center py-4">لا توجد خدمات في هذه الفئة</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* Cases Tab */}
          <TabsContent value="cases" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة القضايا الشرعية</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="h-4 w-4 ml-2" />
                    قضية جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>إضافة قضية شرعية جديدة</DialogTitle>
                  </DialogHeader>
                  <Form {...caseForm}>
                    <form onSubmit={caseForm.handleSubmit(onSubmitCase)} className="space-y-4">
                      <FormField
                        control={caseForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>عنوان القضية</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: قضية مواريث..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={caseForm.control}
                        name="caseType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع القضية</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع القضية" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="inheritance">مواريث</SelectItem>
                                <SelectItem value="marriage">زواج</SelectItem>
                                <SelectItem value="divorce">طلاق</SelectItem>
                                <SelectItem value="financial">معاملات مالية</SelectItem>
                                <SelectItem value="waqf">أوقاف</SelectItem>
                                <SelectItem value="commercial">تجارة شرعية</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={caseForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف القضية</FormLabel>
                            <FormControl>
                              <Textarea placeholder="تفاصيل القضية..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full bg-emerald-600 hover:bg-emerald-700"
                        disabled={createCaseMutation.isPending}
                      >
                        {createCaseMutation.isPending ? "جاري الحفظ..." : "حفظ القضية"}
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {activeCases?.length > 0 ? (
                activeCases.map((case_: any) => (
                  <Card key={case_.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{case_.title}</CardTitle>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{case_.caseType}</p>
                        </div>
                        <div className="flex gap-2">
                          <Badge variant={case_.priority === "high" ? "destructive" : "secondary"}>
                            {case_.priority === "high" ? "عالية" : case_.priority === "medium" ? "متوسطة" : "منخفضة"}
                          </Badge>
                          <Badge variant="outline">{case_.status}</Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 dark:text-gray-300 mb-4">{case_.description}</p>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {new Date(case_.createdAt).toLocaleDateString('ar-YE')}
                          </div>
                          {case_.estimatedValue && (
                            <div className="flex items-center gap-1">
                              <Coins className="h-4 w-4" />
                              {case_.estimatedValue} ر.ي
                            </div>
                          )}
                        </div>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 ml-1" />
                          عرض التفاصيل
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Scale className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                      لا توجد قضايا شرعية
                    </h3>
                    <p className="text-gray-500 mb-4">ابدأ بإضافة قضية شرعية جديدة</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Inheritance Calculator Tab */}
          <TabsContent value="inheritance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  حاسبة المواريث الشرعية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Calculator className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">حاسبة المواريث</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    أداة متقدمة لحساب المواريث وفقاً للشريعة الإسلامية
                  </p>
                  <Button className="bg-emerald-600 hover:bg-emerald-700">
                    فتح حاسبة المواريث
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs would be implemented similarly */}
          <TabsContent value="consultations">
            <Card>
              <CardContent className="text-center py-12">
                <Heart className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">إدارة الاستشارات</h3>
                <p className="text-gray-600 dark:text-gray-400">قريباً...</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents">
            <Card>
              <CardContent className="text-center py-12">
                <FileText className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">إدارة المستندات</h3>
                <p className="text-gray-600 dark:text-gray-400">قريباً...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
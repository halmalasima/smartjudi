import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import NavigationHeader from "@/components/navigation-header";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  suggestions?: string[];
  legalReferences?: string[];
}

export default function AiAssistant() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading, user } = useAuth();
  const [currentQuestion, setCurrentQuestion] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [caseAnalysisText, setCaseAnalysisText] = useState("");
  const [caseType, setCaseType] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "غير مخول",
        description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Auto scroll to bottom when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Fetch conversation history
  const { data: conversations, isLoading: conversationsLoading } = useQuery({
    queryKey: ["/api/ai/conversations"],
    enabled: isAuthenticated,
  });

  // Ask AI mutation
  const askAiMutation = useMutation({
    mutationFn: async (data: { question: string; caseContext?: any }) => {
      const response = await apiRequest("POST", "/api/ai/ask", data);
      return response.json();
    },
    onSuccess: (data) => {
      const aiMessage: Message = {
        id: Date.now().toString() + '-ai',
        type: 'ai',
        content: data.response,
        timestamp: new Date(),
        suggestions: data.suggestions,
        legalReferences: data.legalReferences,
      };
      setMessages(prev => [...prev, aiMessage]);
      setCurrentQuestion("");
      queryClient.invalidateQueries({ queryKey: ["/api/ai/conversations"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غير مخول",
          description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطأ",
        description: "فشل في الحصول على إجابة من المساعد الذكي. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  // Analyze case mutation
  const analyzeCaseMutation = useMutation({
    mutationFn: async (data: { caseDescription: string; caseType: string }) => {
      const response = await apiRequest("POST", "/api/ai/analyze-case", data);
      return response.json();
    },
    onSuccess: (data) => {
      const analysisMessage: Message = {
        id: Date.now().toString() + '-analysis',
        type: 'ai',
        content: `تحليل القضية:\n\n${data.analysis}\n\nالإستراتيجية المقترحة:\n${data.legalStrategy}\n\nالإجراءات الموصى بها:\n${data.recommendedActions.map((action: string, i: number) => `${i + 1}. ${action}`).join('\n')}`,
        timestamp: new Date(),
        suggestions: data.recommendedActions,
        legalReferences: data.requiredDocuments,
      };
      setMessages(prev => [...prev, analysisMessage]);
      setCaseAnalysisText("");
      setCaseType("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غير مخول",
          description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطأ",
        description: "فشل في تحليل القضية. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || !isAuthenticated) {
    return <div className="min-h-screen bg-gray-50" />;
  }

  const handleSubmitQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentQuestion.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString() + '-user',
      type: 'user',
      content: currentQuestion,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    askAiMutation.mutate({ question: currentQuestion });
  };

  const handleAnalyzeCase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseAnalysisText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString() + '-user',
      type: 'user',
      content: `تحليل قضية (${caseType || 'غير محدد'}): ${caseAnalysisText}`,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    analyzeCaseMutation.mutate({ 
      caseDescription: caseAnalysisText, 
      caseType: caseType || '' 
    });
  };

  const suggestedQuestions = [
    "ما هي إجراءات رفع دعوى ملكية عقارية؟",
    "كيف يمكنني صياغة عقد إيجار قانوني؟",
    "ما هي حقوق المستأجر في حالة الإخلاء؟",
    "كيف يتم تسجيل شركة تجارية في اليمن؟",
    "ما هي إجراءات الطلاق في القانون اليمني؟",
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-reverse space-x-4 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
                <i className="fas fa-robot text-white text-2xl"></i>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">المساعد القانوني الذكي</h1>
                <p className="text-gray-600">احصل على استشارات قانونية مدعومة بالذكاء الاصطناعي</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Chat Section */}
            <div className="lg:col-span-3">
              <Tabs defaultValue="chat" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="chat">الدردشة القانونية</TabsTrigger>
                  <TabsTrigger value="analysis">تحليل القضايا</TabsTrigger>
                </TabsList>

                <TabsContent value="chat" className="space-y-4">
                  <Card className="h-[600px] flex flex-col">
                    {/* Chat Messages */}
                    <CardHeader className="border-b">
                      <div className="flex items-center space-x-reverse space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
                          <i className="fas fa-robot text-white text-sm"></i>
                        </div>
                        <div>
                          <CardTitle className="text-lg">مساعد قانوني</CardTitle>
                          <CardDescription>متصل الآن</CardDescription>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="flex-1 p-0">
                      <ScrollArea className="h-full p-4">
                        <div className="space-y-4">
                          {messages.length === 0 && (
                            <div className="text-center py-8">
                              <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <i className="fas fa-comments text-purple-600 text-2xl"></i>
                              </div>
                              <h3 className="text-lg font-semibold text-gray-900 mb-2">مرحباً بك في المساعد القانوني</h3>
                              <p className="text-gray-600">اسأل أي سؤال قانوني وستحصل على إجابة مفصلة مع المراجع القانونية</p>
                            </div>
                          )}

                          {messages.map((message) => (
                            <div
                              key={message.id}
                              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                              <div className={`flex max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'} space-x-reverse space-x-2`}>
                                <Avatar className="w-8 h-8">
                                  <AvatarFallback className={message.type === 'user' ? 'bg-primary-100 text-primary-600' : 'bg-gradient-to-br from-purple-500 to-blue-500 text-white'}>
                                    {message.type === 'user' ? (
                                      user?.firstName?.charAt(0) || 'م'
                                    ) : (
                                      <i className="fas fa-robot text-xs"></i>
                                    )}
                                  </AvatarFallback>
                                </Avatar>
                                <div className={`rounded-lg p-3 ${
                                  message.type === 'user' 
                                    ? 'bg-primary-500 text-white' 
                                    : 'bg-gray-100 text-gray-900'
                                }`}>
                                  <p className="whitespace-pre-wrap">{message.content}</p>
                                  <p className="text-xs mt-2 opacity-70">
                                    {message.timestamp.toLocaleTimeString('ar-YE', {
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    })}
                                  </p>
                                  
                                  {message.suggestions && message.suggestions.length > 0 && (
                                    <div className="mt-3 pt-3 border-t border-gray-200">
                                      <p className="text-sm font-medium mb-2">اقتراحات:</p>
                                      <div className="flex flex-wrap gap-1">
                                        {message.suggestions.slice(0, 3).map((suggestion, index) => (
                                          <Badge key={index} variant="secondary" className="text-xs">
                                            {suggestion}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  )}

                                  {message.legalReferences && message.legalReferences.length > 0 && (
                                    <div className="mt-3 pt-3 border-t border-gray-200">
                                      <p className="text-sm font-medium mb-2">مراجع قانونية:</p>
                                      <div className="flex flex-wrap gap-1">
                                        {message.legalReferences.slice(0, 2).map((reference, index) => (
                                          <Badge key={index} variant="outline" className="text-xs">
                                            {reference}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}

                          {askAiMutation.isPending && (
                            <div className="flex justify-start">
                              <div className="flex space-x-reverse space-x-2">
                                <Avatar className="w-8 h-8">
                                  <AvatarFallback className="bg-gradient-to-br from-purple-500 to-blue-500 text-white">
                                    <i className="fas fa-robot text-xs"></i>
                                  </AvatarFallback>
                                </Avatar>
                                <div className="bg-gray-100 rounded-lg p-3">
                                  <div className="flex items-center space-x-reverse space-x-2">
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-600"></div>
                                    <span className="text-sm text-gray-600">جاري التفكير...</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}

                          <div ref={messagesEndRef} />
                        </div>
                      </ScrollArea>
                    </CardContent>

                    {/* Chat Input */}
                    <div className="border-t p-4">
                      <form onSubmit={handleSubmitQuestion} className="flex gap-2">
                        <Input
                          value={currentQuestion}
                          onChange={(e) => setCurrentQuestion(e.target.value)}
                          placeholder="اكتب سؤالك القانوني هنا..."
                          className="flex-1"
                          disabled={askAiMutation.isPending}
                        />
                        <Button 
                          type="submit" 
                          disabled={!currentQuestion.trim() || askAiMutation.isPending}
                          className="bg-primary-600 hover:bg-primary-700"
                        >
                          <i className="fas fa-paper-plane"></i>
                        </Button>
                      </form>
                    </div>
                  </Card>
                </TabsContent>

                <TabsContent value="analysis" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>تحليل القضايا بالذكاء الاصطناعي</CardTitle>
                      <CardDescription>
                        أدخل تفاصيل القضية للحصول على تحليل شامل واستراتيجية قانونية
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleAnalyzeCase} className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            نوع القضية
                          </label>
                          <Input
                            value={caseType}
                            onChange={(e) => setCaseType(e.target.value)}
                            placeholder="مثال: ملكية عقارية، نزاع تجاري، إيجار..."
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            وصف القضية
                          </label>
                          <Textarea
                            value={caseAnalysisText}
                            onChange={(e) => setCaseAnalysisText(e.target.value)}
                            placeholder="اكتب وصفاً مفصلاً للقضية، الأطراف المعنية، والظروف المحيطة..."
                            className="min-h-[150px]"
                            required
                          />
                        </div>
                        <Button 
                          type="submit" 
                          disabled={!caseAnalysisText.trim() || analyzeCaseMutation.isPending}
                          className="w-full bg-primary-600 hover:bg-primary-700"
                        >
                          {analyzeCaseMutation.isPending ? (
                            <>
                              <i className="fas fa-spinner fa-spin ml-2"></i>
                              جاري التحليل...
                            </>
                          ) : (
                            <>
                              <i className="fas fa-search ml-2"></i>
                              تحليل القضية
                            </>
                          )}
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
              {/* Suggested Questions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">أسئلة مقترحة</CardTitle>
                  <CardDescription>اختر سؤالاً للبدء السريع</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {suggestedQuestions.map((question, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        size="sm"
                        className="w-full text-right justify-start h-auto p-3"
                        onClick={() => {
                          setCurrentQuestion(question);
                          // Focus on input
                          const input = document.querySelector('input[placeholder*="اكتب سؤالك"]') as HTMLInputElement;
                          input?.focus();
                        }}
                      >
                        <span className="text-sm leading-relaxed">{question}</span>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Conversations */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">المحادثات السابقة</CardTitle>
                  <CardDescription>آخر استشاراتك القانونية</CardDescription>
                </CardHeader>
                <CardContent>
                  {conversationsLoading ? (
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="p-3 rounded-lg border">
                          <Skeleton className="h-4 w-full mb-2" />
                          <Skeleton className="h-3 w-2/3" />
                        </div>
                      ))}
                    </div>
                  ) : conversations && conversations.length > 0 ? (
                    <div className="space-y-3">
                      {conversations.slice(0, 5).map((conversation: any) => (
                        <div key={conversation.id} className="p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
                          <p className="text-sm font-medium line-clamp-2 mb-1">
                            {conversation.question}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(conversation.createdAt).toLocaleDateString('ar-YE')}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 text-center py-4">
                      لا توجد محادثات سابقة
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">نصائح للاستخدام</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm text-gray-600">
                    <div className="flex items-start space-x-reverse space-x-2">
                      <i className="fas fa-lightbulb text-yellow-500 mt-0.5"></i>
                      <span>كن مفصلاً في أسئلتك للحصول على إجابات دقيقة</span>
                    </div>
                    <div className="flex items-start space-x-reverse space-x-2">
                      <i className="fas fa-book text-blue-500 mt-0.5"></i>
                      <span>الإجابات مبنية على القانون اليمني</span>
                    </div>
                    <div className="flex items-start space-x-reverse space-x-2">
                      <i className="fas fa-exclamation-triangle text-orange-500 mt-0.5"></i>
                      <span>هذا مساعد استشاري ولا يغني عن الاستشارة القانونية المباشرة</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

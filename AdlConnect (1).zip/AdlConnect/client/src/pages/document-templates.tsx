import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import NavigationHeader from "@/components/navigation-header";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDocumentSchema } from "@shared/schema";
import { z } from "zod";

type DocumentFormData = z.infer<typeof insertDocumentSchema>;

export default function DocumentTemplates() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading, user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedDocument, setSelectedDocument] = useState<any>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "غير مخول",
        description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch document templates
  const { data: templates, isLoading: templatesLoading } = useQuery({
    queryKey: ["/api/documents", { isTemplate: true }],
    enabled: isAuthenticated,
  });

  // Fetch user documents
  const { data: userDocuments, isLoading: userDocsLoading } = useQuery({
    queryKey: ["/api/documents", { isTemplate: false }],
    enabled: isAuthenticated,
  });

  // Create document mutation
  const createDocumentMutation = useMutation({
    mutationFn: async (data: DocumentFormData) => {
      await apiRequest("POST", "/api/documents", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "تم إنشاء المستند",
        description: "تم إنشاء المستند الجديد بنجاح",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غير مخول",
          description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطأ",
        description: "فشل في إنشاء المستند. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  const form = useForm<DocumentFormData>({
    resolver: zodResolver(insertDocumentSchema),
    defaultValues: {
      title: "",
      description: "",
      type: "contract",
      content: "",
      isTemplate: false,
    },
  });

  const onSubmit = (data: DocumentFormData) => {
    createDocumentMutation.mutate(data);
  };

  if (authLoading || !isAuthenticated) {
    return <div className="min-h-screen bg-gray-50" />;
  }

  const getDocumentTypeIcon = (type: string) => {
    const iconMap = {
      contract: "fa-file-contract",
      lawsuit: "fa-gavel",
      court_document: "fa-balance-scale",
      legal_opinion: "fa-file-alt",
      evidence: "fa-folder-open",
      other: "fa-file",
    };
    return iconMap[type as keyof typeof iconMap] || "fa-file";
  };

  const getDocumentTypeLabel = (type: string) => {
    const labelMap = {
      contract: "عقد",
      lawsuit: "دعوى قضائية",
      court_document: "وثيقة محكمة",
      legal_opinion: "رأي قانوني",
      evidence: "دليل",
      other: "أخرى",
    };
    return labelMap[type as keyof typeof labelMap] || type;
  };

  const categories = [
    { value: "", label: "جميع الفئات" },
    { value: "عقود", label: "العقود" },
    { value: "دعاوى", label: "الدعاوى القضائية" },
    { value: "تجاري", label: "الوثائق التجارية" },
    { value: "مدني", label: "الوثائق المدنية" },
    { value: "إداري", label: "الوثائق الإدارية" },
  ];

  const filteredTemplates = templates?.filter((template: any) => {
    const matchesSearch = !searchQuery || 
      template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || template.templateCategory === selectedCategory;
    return matchesSearch && matchesCategory;
  }) || [];

  const predefinedTemplates = [
    {
      id: "contract-rent",
      title: "عقد إيجار سكني",
      description: "نموذج لعقد إيجار العقارات السكنية",
      category: "عقود",
      type: "contract",
      icon: "fa-home",
      color: "bg-blue-100 text-blue-800",
    },
    {
      id: "contract-work",
      title: "عقد عمل",
      description: "نموذج لعقد العمل بين صاحب العمل والموظف",
      category: "عقود",
      type: "contract",
      icon: "fa-briefcase",
      color: "bg-green-100 text-green-800",
    },
    {
      id: "lawsuit-property",
      title: "دعوى ملكية عقارية",
      description: "نموذج لدعوى المطالبة بالملكية العقارية",
      category: "دعاوى",
      type: "lawsuit",
      icon: "fa-building",
      color: "bg-purple-100 text-purple-800",
    },
    {
      id: "lawsuit-commercial",
      title: "دعوى تجارية",
      description: "نموذج للدعاوى التجارية والنزاعات المالية",
      category: "دعاوى",
      type: "lawsuit",
      icon: "fa-handshake",
      color: "bg-orange-100 text-orange-800",
    },
    {
      id: "contract-partnership",
      title: "عقد شراكة تجارية",
      description: "نموذج لعقد الشراكة في الأعمال التجارية",
      category: "تجاري",
      type: "contract",
      icon: "fa-users",
      color: "bg-indigo-100 text-indigo-800",
    },
    {
      id: "power-attorney",
      title: "توكيل قانوني",
      description: "نموذج للتوكيل في الإجراءات القانونية",
      category: "مدني",
      type: "legal_opinion",
      icon: "fa-stamp",
      color: "bg-red-100 text-red-800",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">نماذج الوثائق</h1>
                <p className="text-gray-600">مكتبة شاملة من نماذج العقود والوثائق القانونية</p>
              </div>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary-600 hover:bg-primary-700">
                    <i className="fas fa-plus ml-2"></i>
                    مستند جديد
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>إنشاء مستند جديد</DialogTitle>
                    <DialogDescription>
                      أنشئ مستنداً جديداً أو اختر من النماذج الجاهزة
                    </DialogDescription>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>عنوان المستند</FormLabel>
                            <FormControl>
                              <Input placeholder="أدخل عنوان المستند" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع المستند</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع المستند" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="contract">عقد</SelectItem>
                                <SelectItem value="lawsuit">دعوى قضائية</SelectItem>
                                <SelectItem value="court_document">وثيقة محكمة</SelectItem>
                                <SelectItem value="legal_opinion">رأي قانوني</SelectItem>
                                <SelectItem value="evidence">دليل</SelectItem>
                                <SelectItem value="other">أخرى</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="templateCategory"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>فئة القالب</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ""}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر فئة القالب" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="عقود">العقود</SelectItem>
                                <SelectItem value="دعاوى">الدعاوى القضائية</SelectItem>
                                <SelectItem value="تجاري">الوثائق التجارية</SelectItem>
                                <SelectItem value="مدني">الوثائق المدنية</SelectItem>
                                <SelectItem value="إداري">الوثائق الإدارية</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف المستند</FormLabel>
                            <FormControl>
                              <Textarea placeholder="أدخل وصف المستند" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>محتوى المستند</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="أدخل محتوى المستند" 
                                className="min-h-[200px]" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <DialogFooter>
                        <Button 
                          type="submit" 
                          disabled={createDocumentMutation.isPending}
                          className="bg-primary-600 hover:bg-primary-700"
                        >
                          {createDocumentMutation.isPending ? (
                            <>
                              <i className="fas fa-spinner fa-spin ml-2"></i>
                              جاري الإنشاء...
                            </>
                          ) : (
                            <>
                              <i className="fas fa-plus ml-2"></i>
                              إنشاء المستند
                            </>
                          )}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Tabs defaultValue="templates" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="templates">النماذج الجاهزة</TabsTrigger>
              <TabsTrigger value="my-documents">مستنداتي</TabsTrigger>
              <TabsTrigger value="categories">التصنيفات</TabsTrigger>
            </TabsList>

            <TabsContent value="templates" className="space-y-6">
              {/* Search and Filter */}
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="flex-1 relative">
                  <Input
                    type="text"
                    placeholder="البحث في النماذج..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4"
                  />
                  <i className="fas fa-search absolute right-3 top-3 text-gray-400"></i>
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="sm:w-48">
                    <SelectValue placeholder="اختر الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Predefined Templates Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {predefinedTemplates
                  .filter((template) => {
                    const matchesSearch = !searchQuery || 
                      template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      template.description.toLowerCase().includes(searchQuery.toLowerCase());
                    const matchesCategory = !selectedCategory || template.category === selectedCategory;
                    return matchesSearch && matchesCategory;
                  })
                  .map((template) => (
                  <Card key={template.id} className="hover-lift transition-all duration-200 cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-reverse space-x-3">
                          <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
                            <i className={`fas ${template.icon} text-primary-600 text-lg`}></i>
                          </div>
                          <div>
                            <CardTitle className="text-lg">{template.title}</CardTitle>
                            <Badge className={template.color}>{template.category}</Badge>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          <i className="fas fa-ellipsis-h"></i>
                        </Button>
                      </div>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <Badge variant="outline">{getDocumentTypeLabel(template.type)}</Badge>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <i className="fas fa-eye ml-2"></i>
                            معاينة
                          </Button>
                          <Button size="sm" className="bg-primary-600 hover:bg-primary-700">
                            <i className="fas fa-download ml-2"></i>
                            استخدام
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {/* Custom Templates */}
                {filteredTemplates.map((template: any) => (
                  <Card key={template.id} className="hover-lift transition-all duration-200 cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-reverse space-x-3">
                          <div className="w-12 h-12 bg-secondary-100 rounded-lg flex items-center justify-center">
                            <i className={`fas ${getDocumentTypeIcon(template.type)} text-secondary-600 text-lg`}></i>
                          </div>
                          <div>
                            <CardTitle className="text-lg">{template.title}</CardTitle>
                            <Badge className="bg-secondary-100 text-secondary-800">
                              {template.templateCategory || "قالب مخصص"}
                            </Badge>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          <i className="fas fa-ellipsis-h"></i>
                        </Button>
                      </div>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <Badge variant="outline">{getDocumentTypeLabel(template.type)}</Badge>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <i className="fas fa-eye ml-2"></i>
                            معاينة
                          </Button>
                          <Button size="sm" className="bg-primary-600 hover:bg-primary-700">
                            <i className="fas fa-download ml-2"></i>
                            استخدام
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {/* Empty State */}
                {filteredTemplates.length === 0 && predefinedTemplates.filter((template) => {
                  const matchesSearch = !searchQuery || 
                    template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    template.description.toLowerCase().includes(searchQuery.toLowerCase());
                  const matchesCategory = !selectedCategory || template.category === selectedCategory;
                  return matchesSearch && matchesCategory;
                }).length === 0 && (
                  <div className="col-span-full">
                    <Card>
                      <CardContent className="py-12 text-center">
                        <i className="fas fa-file-alt text-gray-400 text-6xl mb-4"></i>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد نماذج</h3>
                        <p className="text-gray-600">
                          {searchQuery || selectedCategory 
                            ? "لا توجد نماذج تطابق معايير البحث المحددة"
                            : "لا توجد نماذج متاحة حالياً"
                          }
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="my-documents" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userDocsLoading ? (
                  <>
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <Card key={i}>
                        <CardHeader>
                          <div className="flex items-center space-x-reverse space-x-4">
                            <Skeleton className="w-12 h-12 rounded-lg" />
                            <div className="flex-1 space-y-2">
                              <Skeleton className="h-6 w-3/4" />
                              <Skeleton className="h-4 w-1/2" />
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <Skeleton className="h-4 w-full" />
                            <Skeleton className="h-8 w-24" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </>
                ) : userDocuments && userDocuments.length > 0 ? (
                  <>
                    {userDocuments.map((document: any) => (
                      <Card key={document.id} className="hover-lift transition-all duration-200 cursor-pointer">
                        <CardHeader>
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-reverse space-x-3">
                              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                                <i className={`fas ${getDocumentTypeIcon(document.type)} text-purple-600 text-lg`}></i>
                              </div>
                              <div>
                                <CardTitle className="text-lg">{document.title}</CardTitle>
                                <CardDescription>{getDocumentTypeLabel(document.type)}</CardDescription>
                              </div>
                            </div>
                            <Button variant="ghost" size="sm">
                              <i className="fas fa-ellipsis-h"></i>
                            </Button>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 mb-4 line-clamp-2">
                            {document.description || "لا يوجد وصف"}
                          </p>
                          <div className="flex justify-between items-center">
                            <Badge variant="outline">
                              {new Date(document.createdAt).toLocaleDateString('ar-YE')}
                            </Badge>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline">
                                <i className="fas fa-edit ml-2"></i>
                                تحرير
                              </Button>
                              <Button size="sm" className="bg-primary-600 hover:bg-primary-700">
                                <i className="fas fa-download ml-2"></i>
                                تحميل
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </>
                ) : (
                  <div className="col-span-full">
                    <Card>
                      <CardContent className="py-12 text-center">
                        <i className="fas fa-folder-open text-gray-400 text-6xl mb-4"></i>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد مستندات</h3>
                        <p className="text-gray-600 mb-6">لم تقم بإنشاء أي مستندات حتى الآن</p>
                        <Button 
                          onClick={() => setIsCreateDialogOpen(true)}
                          className="bg-primary-600 hover:bg-primary-700"
                        >
                          <i className="fas fa-plus ml-2"></i>
                          إنشاء مستند جديد
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="categories" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {categories.slice(1).map((category) => (
                  <Card key={category.value} className="hover-lift transition-all duration-200 cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center space-x-reverse space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
                          <i className="fas fa-folder text-white text-lg"></i>
                        </div>
                        <div>
                          <CardTitle>{category.label}</CardTitle>
                          <CardDescription>
                            {predefinedTemplates.filter(t => t.category === category.value).length} نموذج
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          setSelectedCategory(category.value);
                          // Switch to templates tab
                          const tabsTrigger = document.querySelector('[value="templates"]') as HTMLElement;
                          tabsTrigger?.click();
                        }}
                      >
                        <i className="fas fa-eye ml-2"></i>
                        عرض النماذج
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}

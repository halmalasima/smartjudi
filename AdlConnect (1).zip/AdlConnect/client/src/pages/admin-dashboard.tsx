import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Settings, 
  Users, 
  CreditCard, 
  BarChart3, 
  Shield, 
  Package,
  Plus,
  Edit,
  Eye,
  Trash2,
  TrendingUp,
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  UserCheck,
  FileText,
  Brain,
  Scale,
  Database
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const subscriptionPlanSchema = z.object({
  name: z.string().min(1, "اسم الخطة مطلوب"),
  nameEn: z.string().min(1, "الاسم الإنجليزي مطلوب"),
  description: z.string().min(1, "وصف الخطة مطلوب"),
  descriptionEn: z.string().min(1, "الوصف الإنجليزي مطلوب"),
  price: z.number().min(0, "السعر يجب أن يكون رقم موجب"),
  duration: z.number().min(1, "مدة الاشتراك مطلوبة"),
  userRole: z.string().min(1, "نوع المستخدم مطلوب"),
  features: z.object({
    maxCases: z.number().optional(),
    maxDocuments: z.number().optional(),
    maxClients: z.number().optional(),
    aiQuestions: z.number().optional(),
    courtIntegration: z.boolean().default(false),
    reportGeneration: z.boolean().default(false),
    prioritySupport: z.boolean().default(false),
    customTemplates: z.boolean().default(false),
    dataBackup: z.boolean().default(false),
    mobileApp: z.boolean().default(false),
  }),
});

type SubscriptionPlanForm = z.infer<typeof subscriptionPlanSchema>;

const governmentServiceSchema = z.object({
  name: z.string().min(1, "اسم الخدمة مطلوب"),
  nameEn: z.string().min(1, "الاسم الإنجليزي مطلوب"),
  description: z.string().optional(),
  ministry: z.string().min(1, "الوزارة مطلوبة"),
  serviceType: z.string().min(1, "نوع الخدمة مطلوب"),
  endpoint: z.string().url("رابط الخدمة يجب أن يكون صحيح"),
  requiredFields: z.array(z.object({
    name: z.string(),
    type: z.string(),
    required: z.boolean(),
    label: z.string(),
  })).optional(),
});

type GovernmentServiceForm = z.infer<typeof governmentServiceSchema>;

export default function AdminDashboard() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedTab, setSelectedTab] = useState("overview");
  const [editingPlan, setEditingPlan] = useState<any>(null);
  const [editingService, setEditingService] = useState<any>(null);

  // Admin statistics
  const { data: adminStats } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  // Subscription plans
  const { data: subscriptionPlans } = useQuery({
    queryKey: ["/api/admin/subscription-plans"],
  });

  // Users
  const { data: users } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  // Government services
  const { data: governmentServices } = useQuery({
    queryKey: ["/api/admin/government-services"],
  });

  // System settings
  const { data: systemSettings } = useQuery({
    queryKey: ["/api/admin/settings"],
  });

  // Forms
  const planForm = useForm<SubscriptionPlanForm>({
    resolver: zodResolver(subscriptionPlanSchema),
    defaultValues: {
      name: "",
      nameEn: "",
      description: "",
      descriptionEn: "",
      price: 0,
      duration: 30,
      userRole: "",
      features: {
        maxCases: 10,
        maxDocuments: 50,
        maxClients: 25,
        aiQuestions: 100,
        courtIntegration: false,
        reportGeneration: false,
        prioritySupport: false,
        customTemplates: false,
        dataBackup: false,
        mobileApp: false,
      },
    },
  });

  const serviceForm = useForm<GovernmentServiceForm>({
    resolver: zodResolver(governmentServiceSchema),
    defaultValues: {
      name: "",
      nameEn: "",
      description: "",
      ministry: "",
      serviceType: "",
      endpoint: "",
      requiredFields: [],
    },
  });

  // Mutations
  const createPlanMutation = useMutation({
    mutationFn: (data: SubscriptionPlanForm) => apiRequest("/api/admin/subscription-plans", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/subscription-plans"] });
      planForm.reset();
      setEditingPlan(null);
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: SubscriptionPlanForm }) => 
      apiRequest(`/api/admin/subscription-plans/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/subscription-plans"] });
      planForm.reset();
      setEditingPlan(null);
    },
  });

  const deletePlanMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/admin/subscription-plans/${id}`, {
      method: "DELETE",
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/subscription-plans"] });
    },
  });

  const createServiceMutation = useMutation({
    mutationFn: (data: GovernmentServiceForm) => apiRequest("/api/admin/government-services", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/government-services"] });
      serviceForm.reset();
      setEditingService(null);
    },
  });

  const updateUserStatusMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: string; isActive: boolean }) =>
      apiRequest(`/api/admin/users/${userId}/status`, {
        method: "PUT",
        body: JSON.stringify({ isActive }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
  });

  const onSubmitPlan = (data: SubscriptionPlanForm) => {
    if (editingPlan) {
      updatePlanMutation.mutate({ id: editingPlan.id, data });
    } else {
      createPlanMutation.mutate(data);
    }
  };

  const onSubmitService = (data: GovernmentServiceForm) => {
    createServiceMutation.mutate(data);
  };

  const handleEditPlan = (plan: any) => {
    setEditingPlan(plan);
    planForm.reset(plan);
  };

  const handleDeletePlan = (id: string) => {
    if (confirm("هل أنت متأكد من حذف هذه الخطة؟")) {
      deletePlanMutation.mutate(id);
    }
  };

  const userRoles = [
    { value: "lawyer", label: "محامي" },
    { value: "legal_secretary", label: "أمين شرعي" },
    { value: "trainee", label: "متدرب" },
    { value: "client", label: "عميل" },
  ];

  const ministries = [
    "وزارة العدل",
    "وزارة الداخلية", 
    "وزارة الأوقاف والإرشاد",
    "وزارة التجارة والصناعة",
    "وزارة المالية"
  ];

  const serviceTypes = [
    { value: "lawsuit_filing", label: "رفع دعوى" },
    { value: "inquiry", label: "استعلام" },
    { value: "complaint", label: "شكوى" },
    { value: "certification", label: "توثيق" },
    { value: "registration", label: "تسجيل" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-200 mb-2">
            لوحة التحكم الإدارية
          </h1>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            إدارة شاملة للمنصة والمستخدمين والخدمات
          </p>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-white/50 dark:bg-gray-800/50">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="plans" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              خطط الاشتراك
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              إدارة المستخدمين
            </TabsTrigger>
            <TabsTrigger value="services" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              الخدمات الحكومية
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              التقارير
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              الإعدادات
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">إجمالي المستخدمين</CardTitle>
                  <Users className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{adminStats?.totalUsers || 0}</div>
                  <p className="text-xs opacity-80">+12% من الشهر الماضي</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الاشتراكات النشطة</CardTitle>
                  <CreditCard className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{adminStats?.activeSubscriptions || 0}</div>
                  <p className="text-xs opacity-80">+8% من الشهر الماضي</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الإيرادات الشهرية</CardTitle>
                  <DollarSign className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{adminStats?.monthlyRevenue || 0} ر.ي</div>
                  <p className="text-xs opacity-80">+25% من الشهر الماضي</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">القضايا النشطة</CardTitle>
                  <Activity className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{adminStats?.activeCases || 0}</div>
                  <p className="text-xs opacity-80">+15% من الشهر الماضي</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activities */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    الأنشطة الأخيرة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <UserCheck className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">تسجيل مستخدم جديد</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">محامي من صنعاء</p>
                      </div>
                      <Badge variant="outline">منذ ساعة</Badge>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                      <CreditCard className="h-5 w-5 text-emerald-600" />
                      <div>
                        <p className="font-medium">اشتراك جديد</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">خطة المحامي المتقدمة</p>
                      </div>
                      <Badge variant="outline">منذ 3 ساعات</Badge>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                      <AlertTriangle className="h-5 w-5 text-amber-600" />
                      <div>
                        <p className="font-medium">خطأ في النظام</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">مشكلة في الاتصال بالخدمات الحكومية</p>
                      </div>
                      <Badge variant="destructive">منذ 5 ساعات</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    حالة النظام
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                        <span>خدمة المصادقة</span>
                      </div>
                      <Badge variant="default" className="bg-emerald-600">عاملة</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                        <span>قاعدة البيانات</span>
                      </div>
                      <Badge variant="default" className="bg-emerald-600">عاملة</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-amber-600" />
                        <span>الخدمات الحكومية</span>
                      </div>
                      <Badge variant="secondary" className="bg-amber-600 text-white">متقطعة</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                        <span>مساعد AI</span>
                      </div>
                      <Badge variant="default" className="bg-emerald-600">عامل</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Subscription Plans Tab */}
          <TabsContent value="plans" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة خطط الاشتراك</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة خطة جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingPlan ? "تعديل خطة الاشتراك" : "إضافة خطة اشتراك جديدة"}
                    </DialogTitle>
                  </DialogHeader>
                  <Form {...planForm}>
                    <form onSubmit={planForm.handleSubmit(onSubmitPlan)} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={planForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>اسم الخطة</FormLabel>
                              <FormControl>
                                <Input placeholder="مثال: خطة المحامي الأساسية" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={planForm.control}
                          name="nameEn"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>الاسم الإنجليزي</FormLabel>
                              <FormControl>
                                <Input placeholder="Basic Lawyer Plan" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={planForm.control}
                          name="price"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>السعر (ر.ي)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="1000"
                                  {...field}
                                  onChange={(e) => field.onChange(Number(e.target.value))}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={planForm.control}
                          name="duration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>المدة (بالأيام)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="30"
                                  {...field}
                                  onChange={(e) => field.onChange(Number(e.target.value))}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={planForm.control}
                        name="userRole"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع المستخدم</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع المستخدم" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {userRoles.map((role) => (
                                  <SelectItem key={role.value} value={role.value}>
                                    {role.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={planForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف الخطة</FormLabel>
                            <FormControl>
                              <Textarea placeholder="وصف تفصيلي للخطة..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={planForm.control}
                        name="descriptionEn"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الوصف الإنجليزي</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Detailed plan description..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Features Section */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">ميزات الخطة</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={planForm.control}
                            name="features.maxCases"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>الحد الأقصى للقضايا</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="10"
                                    {...field}
                                    onChange={(e) => field.onChange(Number(e.target.value))}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.maxDocuments"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>الحد الأقصى للمستندات</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="50"
                                    {...field}
                                    onChange={(e) => field.onChange(Number(e.target.value))}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.maxClients"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>الحد الأقصى للعملاء</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="25"
                                    {...field}
                                    onChange={(e) => field.onChange(Number(e.target.value))}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.aiQuestions"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>أسئلة AI شهرياً</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    placeholder="100"
                                    {...field}
                                    onChange={(e) => field.onChange(Number(e.target.value))}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={planForm.control}
                            name="features.courtIntegration"
                            render={({ field }) => (
                              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                <div>
                                  <FormLabel>ربط المحاكم</FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.reportGeneration"
                            render={({ field }) => (
                              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                <div>
                                  <FormLabel>إنشاء التقارير</FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.prioritySupport"
                            render={({ field }) => (
                              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                <div>
                                  <FormLabel>دعم عالي الأولوية</FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.customTemplates"
                            render={({ field }) => (
                              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                <div>
                                  <FormLabel>نماذج مخصصة</FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.dataBackup"
                            render={({ field }) => (
                              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                <div>
                                  <FormLabel>نسخ احتياطي</FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={planForm.control}
                            name="features.mobileApp"
                            render={({ field }) => (
                              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                <div>
                                  <FormLabel>تطبيق الهاتف</FormLabel>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button 
                          type="submit" 
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                          disabled={createPlanMutation.isPending || updatePlanMutation.isPending}
                        >
                          {createPlanMutation.isPending || updatePlanMutation.isPending ? "جاري الحفظ..." : editingPlan ? "تحديث الخطة" : "حفظ الخطة"}
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => {
                            setEditingPlan(null);
                            planForm.reset();
                          }}
                        >
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subscriptionPlans?.map((plan: any) => (
                <Card key={plan.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{plan.name}</CardTitle>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{plan.userRole}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => handleEditPlan(plan)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDeletePlan(plan.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">{plan.price} ر.ي</div>
                        <div className="text-sm text-gray-500">لمدة {plan.duration} يوم</div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>القضايا:</span>
                          <span>{plan.features?.maxCases || "غير محدود"}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>المستندات:</span>
                          <span>{plan.features?.maxDocuments || "غير محدود"}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>العملاء:</span>
                          <span>{plan.features?.maxClients || "غير محدود"}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>أسئلة AI:</span>
                          <span>{plan.features?.aiQuestions || "غير محدود"}</span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        {plan.features?.courtIntegration && (
                          <Badge variant="secondary" className="mr-1">ربط المحاكم</Badge>
                        )}
                        {plan.features?.reportGeneration && (
                          <Badge variant="secondary" className="mr-1">التقارير</Badge>
                        )}
                        {plan.features?.prioritySupport && (
                          <Badge variant="secondary" className="mr-1">دعم أولوية</Badge>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <Badge variant={plan.isActive ? "default" : "secondary"}>
                          {plan.isActive ? "نشطة" : "معطلة"}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          {plan.subscriptionsCount || 0} مشترك
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة المستخدمين</h2>
              <div className="flex gap-2">
                <Input placeholder="البحث في المستخدمين..." className="w-80" />
                <Button variant="outline">تصدير</Button>
              </div>
            </div>

            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المستخدم</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>الاشتراك</TableHead>
                    <TableHead>تاريخ التسجيل</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users?.map((user: any) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                            {user.firstName?.charAt(0) || "؟"}
                          </div>
                          <div>
                            <div className="font-medium">{user.firstName} {user.lastName}</div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {userRoles.find(r => r.value === user.role)?.label || user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.activeSubscription ? (
                          <Badge variant="default">{user.activeSubscription.planName}</Badge>
                        ) : (
                          <Badge variant="secondary">بدون اشتراك</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {new Date(user.createdAt).toLocaleDateString('ar-YE')}
                      </TableCell>
                      <TableCell>
                        <Switch
                          checked={user.isActive}
                          onCheckedChange={(checked) => 
                            updateUserStatusMutation.mutate({ userId: user.id, isActive: checked })
                          }
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          {/* Government Services Tab */}
          <TabsContent value="services" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة الخدمات الحكومية</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة خدمة جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>إضافة خدمة حكومية جديدة</DialogTitle>
                  </DialogHeader>
                  <Form {...serviceForm}>
                    <form onSubmit={serviceForm.handleSubmit(onSubmitService)} className="space-y-4">
                      <FormField
                        control={serviceForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>اسم الخدمة</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: رفع دعوى مدنية" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={serviceForm.control}
                        name="nameEn"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الاسم الإنجليزي</FormLabel>
                            <FormControl>
                              <Input placeholder="Civil Lawsuit Filing" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={serviceForm.control}
                        name="ministry"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الوزارة</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر الوزارة" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {ministries.map((ministry) => (
                                  <SelectItem key={ministry} value={ministry}>
                                    {ministry}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={serviceForm.control}
                        name="serviceType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع الخدمة</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع الخدمة" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {serviceTypes.map((type) => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={serviceForm.control}
                        name="endpoint"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>رابط API</FormLabel>
                            <FormControl>
                              <Input placeholder="https://api.justice.gov.ye/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={serviceForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف الخدمة</FormLabel>
                            <FormControl>
                              <Textarea placeholder="وصف تفصيلي للخدمة..." {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        disabled={createServiceMutation.isPending}
                      >
                        {createServiceMutation.isPending ? "جاري الحفظ..." : "حفظ الخدمة"}
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {governmentServices?.map((service: any) => (
                <Card key={service.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{service.name}</CardTitle>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{service.ministry}</p>
                      </div>
                      <Badge variant={service.isActive ? "default" : "secondary"}>
                        {service.isActive ? "نشطة" : "معطلة"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {service.description}
                      </p>
                      <div className="flex justify-between items-center text-sm">
                        <span>النوع:</span>
                        <Badge variant="outline">
                          {serviceTypes.find(t => t.value === service.serviceType)?.label}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span>الطلبات:</span>
                        <span>{service.requestsCount || 0}</span>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="h-4 w-4 ml-1" />
                          عرض
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Edit className="h-4 w-4 ml-1" />
                          تعديل
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports">
            <Card>
              <CardContent className="text-center py-12">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">التقارير والإحصائيات</h3>
                <p className="text-gray-600 dark:text-gray-400">قريباً...</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card>
              <CardContent className="text-center py-12">
                <Settings className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">إعدادات النظام</h3>
                <p className="text-gray-600 dark:text-gray-400">قريباً...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
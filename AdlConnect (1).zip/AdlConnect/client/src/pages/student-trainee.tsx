import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  GraduationCap, 
  BookOpen, 
  Users, 
  Award, 
  Target, 
  Calendar,
  Clock,
  Star,
  Search,
  Play,
  Download,
  FileText,
  MessageCircle,
  Brain,
  Scale,
  Lightbulb,
  TrendingUp
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const practiceRequestSchema = z.object({
  title: z.string().min(1, "عنوان الطلب مطلوب"),
  description: z.string().min(1, "وصف الطلب مطلوب"),
  type: z.string().min(1, "نوع التدريب مطلوب"),
  duration: z.string().min(1, "مدة التدريب مطلوبة"),
  experience: z.string().min(1, "الخبرة السابقة مطلوبة"),
});

type PracticeRequestForm = z.infer<typeof practiceRequestSchema>;

export default function StudentTrainee() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedTab, setSelectedTab] = useState("dashboard");
  const [searchTerm, setSearchTerm] = useState("");

  // Dashboard statistics
  const { data: stats } = useQuery({
    queryKey: ["/api/student/stats"],
  });

  // Courses and materials
  const { data: courses } = useQuery({
    queryKey: ["/api/courses"],
  });

  // Practice opportunities
  const { data: practiceOpportunities } = useQuery({
    queryKey: ["/api/practice-opportunities"],
  });

  // My progress
  const { data: progress } = useQuery({
    queryKey: ["/api/student/progress"],
  });

  // Legal database for students
  const { data: studentResources } = useQuery({
    queryKey: ["/api/student/resources"],
  });

  // Forms
  const practiceForm = useForm<PracticeRequestForm>({
    resolver: zodResolver(practiceRequestSchema),
    defaultValues: {
      title: "",
      description: "",
      type: "",
      duration: "",
      experience: "",
    },
  });

  // Mutations
  const applyForPracticeMutation = useMutation({
    mutationFn: (data: PracticeRequestForm) => apiRequest("/api/practice-applications", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/practice-opportunities"] });
      practiceForm.reset();
    },
  });

  const onSubmitPractice = (data: PracticeRequestForm) => {
    applyForPracticeMutation.mutate(data);
  };

  const courseCategories = [
    { 
      id: "law", 
      title: "القانون اليمني", 
      icon: Scale, 
      color: "bg-blue-500",
      courses: [
        "القانون المدني اليمني",
        "قانون الأحوال الشخصية",
        "القانون التجاري",
        "القانون الإداري"
      ]
    },
    { 
      id: "sharia", 
      title: "الشريعة الإسلامية", 
      icon: BookOpen, 
      color: "bg-emerald-500",
      courses: [
        "فقه المعاملات",
        "فقه الأسرة",
        "فقه الجنايات والعقوبات",
        "أصول الفقه"
      ]
    },
    { 
      id: "practice", 
      title: "التطبيق العملي", 
      icon: Target, 
      color: "bg-orange-500",
      courses: [
        "صياغة العقود",
        "إجراءات التقاضي",
        "فن المرافعة",
        "البحث القانوني"
      ]
    },
    { 
      id: "ethics", 
      title: "أخلاقيات المهنة", 
      icon: Award, 
      color: "bg-purple-500",
      courses: [
        "آداب المحاماة",
        "أخلاقيات القضاء",
        "السرية المهنية",
        "العدالة والنزاهة"
      ]
    }
  ];

  const practiceTypes = [
    { value: "court", label: "التدريب في المحاكم" },
    { value: "law_firm", label: "التدريب في مكاتب المحاماة" },
    { value: "legal_consultancy", label: "الاستشارات القانونية" },
    { value: "sharia_office", label: "مكاتب الأمناء الشرعيين" },
    { value: "legal_research", label: "البحث القانوني" },
    { value: "documentation", label: "التوثيق والعقود" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 p-4" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-blue-800 dark:text-blue-200 mb-2">
            منصة طلاب الشريعة والقانون
          </h1>
          <p className="text-blue-600 dark:text-blue-400 text-lg">
            التعلم والتدريب العملي في المجال القانوني والشرعي
          </p>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-white/50 dark:bg-gray-800/50">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              لوحة التحكم
            </TabsTrigger>
            <TabsTrigger value="courses" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              المواد التعليمية
            </TabsTrigger>
            <TabsTrigger value="practice" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              فرص التدريب
            </TabsTrigger>
            <TabsTrigger value="progress" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              تقدمي الأكاديمي
            </TabsTrigger>
            <TabsTrigger value="resources" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              المراجع والمصادر
            </TabsTrigger>
            <TabsTrigger value="community" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              مجتمع الطلاب
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">المواد المكتملة</CardTitle>
                  <BookOpen className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.completedCourses || 0}</div>
                  <p className="text-xs opacity-80">من أصل {stats?.totalCourses || 0} مادة</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">ساعات التدريب</CardTitle>
                  <Clock className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.practiceHours || 0}</div>
                  <p className="text-xs opacity-80">ساعة تدريب عملي</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-amber-500 to-orange-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الدرجات المحققة</CardTitle>
                  <Star className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.averageGrade || 0}%</div>
                  <p className="text-xs opacity-80">المعدل العام</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500 to-pink-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الشهادات</CardTitle>
                  <Award className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.certificates || 0}</div>
                  <p className="text-xs opacity-80">شهادة مكتسبة</p>
                </CardContent>
              </Card>
            </div>

            {/* Current Progress */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    التقدم الحالي
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">القانون المدني</span>
                        <span className="text-sm text-gray-500">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">فقه المعاملات</span>
                        <span className="text-sm text-gray-500">70%</span>
                      </div>
                      <Progress value={70} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">صياغة العقود</span>
                        <span className="text-sm text-gray-500">60%</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">أخلاقيات المحاماة</span>
                        <span className="text-sm text-gray-500">95%</span>
                      </div>
                      <Progress value={95} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    المهام القادمة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <div>
                        <h4 className="font-medium">امتحان القانون المدني</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">الفصل الخامس</p>
                      </div>
                      <Badge variant="destructive">3 أيام</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                      <div>
                        <h4 className="font-medium">بحث في الأحوال الشخصية</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">مشروع نهائي</p>
                      </div>
                      <Badge variant="outline">أسبوع</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                      <div>
                        <h4 className="font-medium">تدريب في محكمة صنعاء</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">10 ساعات</p>
                      </div>
                      <Badge variant="secondary">شهر</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="البحث في المواد..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pr-10 w-80"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {courseCategories.map((category) => (
                <Card key={category.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <div className={`p-2 rounded-lg ${category.color} text-white`}>
                        <category.icon className="h-5 w-5" />
                      </div>
                      {category.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {category.courses.map((course, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div className="flex items-center gap-3">
                            <BookOpen className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">{course}</span>
                          </div>
                          <Button variant="outline" size="sm">
                            <Play className="h-4 w-4 ml-1" />
                            بدء
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Practice Tab */}
          <TabsContent value="practice" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">فرص التدريب العملي</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    طلب تدريب
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>تقديم طلب تدريب</DialogTitle>
                  </DialogHeader>
                  <Form {...practiceForm}>
                    <form onSubmit={practiceForm.handleSubmit(onSubmitPractice)} className="space-y-4">
                      <FormField
                        control={practiceForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>عنوان الطلب</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: طلب تدريب في محكمة صنعاء" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={practiceForm.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع التدريب</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع التدريب" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {practiceTypes.map((type) => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={practiceForm.control}
                        name="duration"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>مدة التدريب المطلوبة</FormLabel>
                            <FormControl>
                              <Input placeholder="مثال: شهرين" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={practiceForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف الطلب</FormLabel>
                            <FormControl>
                              <Textarea placeholder="اشرح أهدافك من التدريب..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={practiceForm.control}
                        name="experience"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الخبرة السابقة</FormLabel>
                            <FormControl>
                              <Textarea placeholder="اذكر أي خبرة سابقة أو مهارات ذات صلة..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        disabled={applyForPracticeMutation.isPending}
                      >
                        {applyForPracticeMutation.isPending ? "جاري الإرسال..." : "تقديم الطلب"}
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {practiceTypes.map((type) => (
                <Card key={type.value} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">{type.label}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                        <Clock className="h-4 w-4" />
                        مدة التدريب: 1-6 أشهر
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                        <Users className="h-4 w-4" />
                        الأماكن المتاحة: متعددة
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                        <Award className="h-4 w-4" />
                        شهادة معتمدة عند الإكمال
                      </div>
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        عرض الفرص المتاحة
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Progress Tab */}
          <TabsContent value="progress" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>إحصائيات الأداء</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span>المعدل العام</span>
                        <span className="font-bold text-2xl text-blue-600">85%</span>
                      </div>
                      <Progress value={85} className="h-3" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">12</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">مواد مكتملة</div>
                      </div>
                      <div className="text-center p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-emerald-600">150</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">ساعة دراسة</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>الشهادات والإنجازات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                      <Award className="h-8 w-8 text-amber-600" />
                      <div>
                        <h4 className="font-medium">شهادة في القانون المدني</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">مايو 2024</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                      <Award className="h-8 w-8 text-emerald-600" />
                      <div>
                        <h4 className="font-medium">شهادة في فقه المعاملات</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">أبريل 2024</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <Award className="h-8 w-8 text-blue-600" />
                      <div>
                        <h4 className="font-medium">شهادة أخلاقيات المحاماة</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">مارس 2024</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Scale className="h-5 w-5" />
                    القوانين اليمنية
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 ml-2" />
                      القانون المدني
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 ml-2" />
                      قانون الأحوال الشخصية
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 ml-2" />
                      القانون التجاري
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 ml-2" />
                      قانون المرافعات
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    المراجع الشرعية
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="h-4 w-4 ml-2" />
                      كتب فقه المعاملات
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="h-4 w-4 ml-2" />
                      أحكام الأسرة
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="h-4 w-4 ml-2" />
                      فقه المواريث
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="h-4 w-4 ml-2" />
                      أصول الفقه
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5" />
                    أدوات عملية
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <Brain className="h-4 w-4 ml-2" />
                      مساعد AI القانوني
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 ml-2" />
                      نماذج العقود
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Target className="h-4 w-4 ml-2" />
                      اختبارات تقييمية
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <MessageCircle className="h-4 w-4 ml-2" />
                      منتدى النقاش
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Community Tab */}
          <TabsContent value="community" className="space-y-6">
            <Card>
              <CardContent className="text-center py-12">
                <Users className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">مجتمع الطلاب والمتدربين</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  تواصل مع زملائك واستفد من خبرات المحترفين
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button variant="outline">منتدى النقاش</Button>
                  <Button variant="outline">مجموعات الدراسة</Button>
                  <Button variant="outline">شبكة التواصل</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
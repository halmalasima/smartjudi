import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import NavigationHeader from "@/components/navigation-header";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function LegalDatabase() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedLaw, setSelectedLaw] = useState<any>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "غير مخول",
        description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch laws
  const { data: laws, isLoading: lawsLoading } = useQuery({
    queryKey: ["/api/laws", { search: searchQuery, category: selectedCategory }],
    enabled: isAuthenticated,
  });

  // Fetch courts
  const { data: courts, isLoading: courtsLoading } = useQuery({
    queryKey: ["/api/courts"],
    enabled: isAuthenticated,
  });

  if (authLoading || !isAuthenticated) {
    return <div className="min-h-screen bg-gray-50" />;
  }

  const handleSearch = () => {
    // The search is handled automatically by the query key dependency
  };

  const categories = [
    { value: "", label: "جميع الفئات" },
    { value: "مدني", label: "القانون المدني" },
    { value: "تجاري", label: "القانون التجاري" },
    { value: "جنائي", label: "القانون الجنائي" },
    { value: "إداري", label: "القانون الإداري" },
    { value: "أحوال شخصية", label: "قانون الأحوال الشخصية" },
    { value: "عمل", label: "قانون العمل" },
  ];

  const getCategoryIcon = (category: string) => {
    const iconMap = {
      'مدني': 'fa-user',
      'تجاري': 'fa-handshake',
      'جنائي': 'fa-gavel',
      'إداري': 'fa-building',
      'أحوال شخصية': 'fa-users',
      'عمل': 'fa-briefcase',
    };
    return iconMap[category as keyof typeof iconMap] || 'fa-book';
  };

  const getCourtTypeIcon = (type: string) => {
    const iconMap = {
      'مدني': 'fa-balance-scale',
      'جنائي': 'fa-gavel',
      'تجاري': 'fa-handshake',
      'إداري': 'fa-building',
    };
    return iconMap[type as keyof typeof iconMap] || 'fa-landmark';
  };

  const filteredLaws = laws?.filter((law: any) => {
    const matchesSearch = !searchQuery || 
      law.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      law.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (law.keywords && law.keywords.some((keyword: string) => 
        keyword.toLowerCase().includes(searchQuery.toLowerCase())
      ));
    const matchesCategory = !selectedCategory || law.category === selectedCategory;
    return matchesSearch && matchesCategory;
  }) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-6">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">قاعدة القوانين</h1>
            <p className="text-gray-600">مكتبة شاملة للقوانين واللوائح اليمنية</p>
          </div>

          <Tabs defaultValue="laws" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="laws">القوانين واللوائح</TabsTrigger>
              <TabsTrigger value="courts">دليل المحاكم</TabsTrigger>
              <TabsTrigger value="search">البحث المتقدم</TabsTrigger>
            </TabsList>
            
            <TabsContent value="laws" className="space-y-6">
              {/* Search and Filter Bar */}
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="flex-1 relative">
                  <Input
                    type="text"
                    placeholder="البحث في القوانين والأحكام..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4"
                  />
                  <i className="fas fa-search absolute right-3 top-3 text-gray-400"></i>
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="sm:w-48">
                    <SelectValue placeholder="اختر الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={handleSearch} className="bg-primary-600 hover:bg-primary-700">
                  <i className="fas fa-search ml-2"></i>
                  بحث
                </Button>
              </div>

              {/* Laws List */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Laws List */}
                <div className="lg:col-span-2 space-y-4">
                  {lawsLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <Card key={i}>
                          <CardHeader>
                            <div className="flex items-center space-x-reverse space-x-4">
                              <Skeleton className="w-10 h-10 rounded-full" />
                              <div className="flex-1 space-y-2">
                                <Skeleton className="h-6 w-3/4" />
                                <Skeleton className="h-4 w-1/2" />
                              </div>
                              <Skeleton className="h-6 w-16" />
                            </div>
                          </CardHeader>
                        </Card>
                      ))}
                    </div>
                  ) : filteredLaws.length > 0 ? (
                    <div className="space-y-4">
                      {filteredLaws.map((law: any) => (
                        <Card 
                          key={law.id} 
                          className={`hover-lift transition-all duration-200 cursor-pointer ${
                            selectedLaw?.id === law.id ? 'ring-2 ring-primary-500' : ''
                          }`}
                          onClick={() => setSelectedLaw(law)}
                        >
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div className="flex items-start space-x-reverse space-x-4 flex-1">
                                <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center mt-1">
                                  <i className={`fas ${getCategoryIcon(law.category)} text-primary-600`}></i>
                                </div>
                                <div className="flex-1">
                                  <CardTitle className="text-lg mb-2">{law.title}</CardTitle>
                                  <div className="flex items-center space-x-reverse space-x-2 mb-2">
                                    {law.number && (
                                      <Badge variant="outline">رقم {law.number}</Badge>
                                    )}
                                    {law.year && (
                                      <Badge variant="outline">سنة {law.year}</Badge>
                                    )}
                                    <Badge className="bg-primary-100 text-primary-800">
                                      {law.category}
                                    </Badge>
                                  </div>
                                  <CardDescription className="line-clamp-2">
                                    {law.summary || law.content.substring(0, 150) + "..."}
                                  </CardDescription>
                                </div>
                              </div>
                              <Button variant="ghost" size="sm">
                                <i className="fas fa-chevron-left"></i>
                              </Button>
                            </div>
                            {law.keywords && law.keywords.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {law.keywords.slice(0, 3).map((keyword: string, index: number) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {keyword}
                                  </Badge>
                                ))}
                                {law.keywords.length > 3 && (
                                  <Badge variant="secondary" className="text-xs">
                                    +{law.keywords.length - 3}
                                  </Badge>
                                )}
                              </div>
                            )}
                          </CardHeader>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="py-12 text-center">
                        <i className="fas fa-search text-gray-400 text-6xl mb-4"></i>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد نتائج</h3>
                        <p className="text-gray-600">
                          {searchQuery || selectedCategory 
                            ? "لا توجد قوانين تطابق معايير البحث المحددة"
                            : "لا توجد قوانين متاحة حالياً"
                          }
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Law Details */}
                <div className="lg:col-span-1">
                  {selectedLaw ? (
                    <Card className="sticky top-6">
                      <CardHeader>
                        <div className="flex items-center space-x-reverse space-x-3 mb-4">
                          <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                            <i className={`fas ${getCategoryIcon(selectedLaw.category)} text-primary-600`}></i>
                          </div>
                          <div>
                            <CardTitle className="text-lg">{selectedLaw.title}</CardTitle>
                            <CardDescription>{selectedLaw.category}</CardDescription>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {selectedLaw.number && (
                            <Badge variant="outline">رقم {selectedLaw.number}</Badge>
                          )}
                          {selectedLaw.year && (
                            <Badge variant="outline">سنة {selectedLaw.year}</Badge>
                          )}
                          {selectedLaw.publishedDate && (
                            <Badge variant="outline">
                              {new Date(selectedLaw.publishedDate).toLocaleDateString('ar-YE')}
                            </Badge>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {selectedLaw.summary && (
                            <div>
                              <h4 className="font-semibold text-gray-900 mb-2">الملخص:</h4>
                              <p className="text-sm text-gray-600">{selectedLaw.summary}</p>
                            </div>
                          )}
                          
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-2">المحتوى:</h4>
                            <div className="max-h-96 overflow-y-auto">
                              <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">
                                {selectedLaw.content}
                              </p>
                            </div>
                          </div>

                          {selectedLaw.keywords && selectedLaw.keywords.length > 0 && (
                            <div>
                              <h4 className="font-semibold text-gray-900 mb-2">الكلمات المفتاحية:</h4>
                              <div className="flex flex-wrap gap-1">
                                {selectedLaw.keywords.map((keyword: string, index: number) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {keyword}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex gap-2 mt-6">
                            <Button size="sm" className="flex-1">
                              <i className="fas fa-download ml-2"></i>
                              تحميل
                            </Button>
                            <Button variant="outline" size="sm" className="flex-1">
                              <i className="fas fa-share ml-2"></i>
                              مشاركة
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card>
                      <CardContent className="py-12 text-center">
                        <i className="fas fa-file-alt text-gray-400 text-4xl mb-4"></i>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">اختر قانوناً لعرضه</h3>
                        <p className="text-gray-600 text-sm">انقر على أي قانون من القائمة لعرض تفاصيله</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="courts" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {courtsLoading ? (
                  <>
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <Card key={i}>
                        <CardHeader>
                          <div className="flex items-center space-x-reverse space-x-4">
                            <Skeleton className="w-12 h-12 rounded-lg" />
                            <div className="flex-1 space-y-2">
                              <Skeleton className="h-6 w-3/4" />
                              <Skeleton className="h-4 w-1/2" />
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <Skeleton className="h-4 w-full" />
                            <Skeleton className="h-4 w-2/3" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </>
                ) : courts && courts.length > 0 ? (
                  <>
                    {courts.map((court: any) => (
                      <Card key={court.id} className="hover-lift transition-all duration-200">
                        <CardHeader>
                          <div className="flex items-center space-x-reverse space-x-4">
                            <div className="w-12 h-12 bg-secondary-100 rounded-lg flex items-center justify-center">
                              <i className={`fas ${getCourtTypeIcon(court.type)} text-secondary-600 text-lg`}></i>
                            </div>
                            <div>
                              <CardTitle className="text-lg">{court.name}</CardTitle>
                              <CardDescription>{court.type}</CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 text-sm text-gray-600">
                            {court.address && (
                              <div className="flex items-center space-x-reverse space-x-2">
                                <i className="fas fa-map-marker-alt text-gray-400"></i>
                                <span>{court.address}</span>
                              </div>
                            )}
                            {court.phone && (
                              <div className="flex items-center space-x-reverse space-x-2">
                                <i className="fas fa-phone text-gray-400"></i>
                                <span>{court.phone}</span>
                              </div>
                            )}
                            {court.email && (
                              <div className="flex items-center space-x-reverse space-x-2">
                                <i className="fas fa-envelope text-gray-400"></i>
                                <span>{court.email}</span>
                              </div>
                            )}
                            {court.city && (
                              <div className="flex items-center space-x-reverse space-x-2">
                                <i className="fas fa-city text-gray-400"></i>
                                <span>{court.city}, {court.governorate}</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </>
                ) : (
                  <div className="col-span-full">
                    <Card>
                      <CardContent className="py-12 text-center">
                        <i className="fas fa-landmark text-gray-400 text-6xl mb-4"></i>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد محاكم</h3>
                        <p className="text-gray-600">لا توجد محاكم مسجلة في النظام حالياً</p>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="search" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>البحث المتقدم</CardTitle>
                  <CardDescription>استخدم المعايير المتقدمة للبحث في قاعدة البيانات القانونية</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">رقم القانون</label>
                      <Input placeholder="أدخل رقم القانون" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">سنة الإصدار</label>
                      <Input placeholder="أدخل سنة الإصدار" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">تاريخ النشر من</label>
                      <Input type="date" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">تاريخ النشر إلى</label>
                      <Input type="date" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">الكلمات المفتاحية</label>
                      <Input placeholder="كلمات مفتاحية مفصولة بفواصل" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">حالة القانون</label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر الحالة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">ساري المفعول</SelectItem>
                          <SelectItem value="amended">معدل</SelectItem>
                          <SelectItem value="repealed">ملغي</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 mt-6">
                    <Button variant="outline">
                      <i className="fas fa-undo ml-2"></i>
                      إعادة تعيين
                    </Button>
                    <Button className="bg-primary-600 hover:bg-primary-700">
                      <i className="fas fa-search ml-2"></i>
                      بحث متقدم
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import NavigationHeader from "@/components/navigation-header";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCaseSchema } from "@shared/schema";
import { z } from "zod";

type CaseFormData = z.infer<typeof insertCaseSchema>;

export default function CaseManagement() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading, user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "غير مخول",
        description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch cases
  const { data: cases, isLoading: casesLoading, error: casesError } = useQuery({
    queryKey: ["/api/cases"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Create case mutation
  const createCaseMutation = useMutation({
    mutationFn: async (data: CaseFormData) => {
      await apiRequest("POST", "/api/cases", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cases"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "تم إنشاء القضية",
        description: "تم إنشاء القضية الجديدة بنجاح",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غير مخول",
          description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطأ",
        description: "فشل في إنشاء القضية. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  const form = useForm<CaseFormData>({
    resolver: zodResolver(insertCaseSchema),
    defaultValues: {
      title: "",
      description: "",
      caseType: "",
      priority: "medium",
    },
  });

  const onSubmit = (data: CaseFormData) => {
    createCaseMutation.mutate(data);
  };

  if (authLoading || !isAuthenticated) {
    return <div className="min-h-screen bg-gray-50" />;
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      new: { label: "جديدة", className: "bg-blue-100 text-blue-800" },
      under_review: { label: "قيد المراجعة", className: "bg-yellow-100 text-yellow-800" },
      accepted: { label: "مقبولة", className: "bg-green-100 text-green-800" },
      in_progress: { label: "قيد التنفيذ", className: "bg-purple-100 text-purple-800" },
      completed: { label: "مكتملة", className: "bg-secondary-100 text-secondary-800" },
      closed: { label: "مغلقة", className: "bg-gray-100 text-gray-800" },
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || { label: status, className: "bg-gray-100 text-gray-800" };
    return (
      <Badge className={`${statusInfo.className} text-xs font-medium px-2 py-1 rounded-full`}>
        {statusInfo.label}
      </Badge>
    );
  };

  const getPriorityBadge = (priority: string) => {
    const priorityMap = {
      high: { label: "عالية", className: "bg-red-100 text-red-800" },
      medium: { label: "متوسطة", className: "bg-yellow-100 text-yellow-800" },
      low: { label: "منخفضة", className: "bg-green-100 text-green-800" },
    };
    
    const priorityInfo = priorityMap[priority as keyof typeof priorityMap] || { label: priority, className: "bg-gray-100 text-gray-800" };
    return (
      <Badge className={`${priorityInfo.className} text-xs font-medium px-2 py-1 rounded-full`}>
        {priorityInfo.label}
      </Badge>
    );
  };

  const getCaseTypeIcon = (caseType: string) => {
    const iconMap = {
      'ملكية': 'fa-home',
      'تجاري': 'fa-handshake', 
      'إيجار': 'fa-key',
      'جنائي': 'fa-gavel',
      'إداري': 'fa-building',
      'مدني': 'fa-file-alt',
    };
    return iconMap[caseType as keyof typeof iconMap] || 'fa-file-alt';
  };

  const filteredCases = cases?.filter((caseItem: any) =>
    caseItem.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    caseItem.caseType?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    caseItem.caseNumber?.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">إدارة القضايا</h1>
                <p className="text-gray-600">إدارة ومتابعة جميع القضايا القانونية</p>
              </div>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary-600 hover:bg-primary-700">
                    <i className="fas fa-plus ml-2"></i>
                    قضية جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>إنشاء قضية جديدة</DialogTitle>
                    <DialogDescription>
                      أدخل تفاصيل القضية الجديدة
                    </DialogDescription>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>عنوان القضية</FormLabel>
                            <FormControl>
                              <Input placeholder="أدخل عنوان القضية" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="caseType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع القضية</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع القضية" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="مدني">مدني</SelectItem>
                                <SelectItem value="تجاري">تجاري</SelectItem>
                                <SelectItem value="جنائي">جنائي</SelectItem>
                                <SelectItem value="إداري">إداري</SelectItem>
                                <SelectItem value="ملكية">ملكية</SelectItem>
                                <SelectItem value="إيجار">إيجار</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الأولوية</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر الأولوية" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="high">عالية</SelectItem>
                                <SelectItem value="medium">متوسطة</SelectItem>
                                <SelectItem value="low">منخفضة</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف القضية</FormLabel>
                            <FormControl>
                              <Textarea placeholder="أدخل وصف تفصيلي للقضية" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <DialogFooter>
                        <Button 
                          type="submit" 
                          disabled={createCaseMutation.isPending}
                          className="bg-primary-600 hover:bg-primary-700"
                        >
                          {createCaseMutation.isPending ? (
                            <>
                              <i className="fas fa-spinner fa-spin ml-2"></i>
                              جاري الإنشاء...
                            </>
                          ) : (
                            <>
                              <i className="fas fa-plus ml-2"></i>
                              إنشاء القضية
                            </>
                          )}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative max-w-md">
              <Input
                type="text"
                placeholder="البحث في القضايا..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4"
              />
              <i className="fas fa-search absolute right-3 top-3 text-gray-400"></i>
            </div>
          </div>

          {/* Cases Grid */}
          {casesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="hover-lift">
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                      <div className="flex justify-between">
                        <Skeleton className="h-6 w-16" />
                        <Skeleton className="h-6 w-16" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredCases.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCases.map((caseItem: any) => (
                <Card key={caseItem.id} className="hover-lift transition-all duration-200 cursor-pointer">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-reverse space-x-3">
                        <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                          <i className={`fas ${getCaseTypeIcon(caseItem.caseType)} text-primary-600`}></i>
                        </div>
                        <div>
                          <CardTitle className="text-lg">{caseItem.title}</CardTitle>
                          <CardDescription>{caseItem.caseType}</CardDescription>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <i className="fas fa-ellipsis-h"></i>
                      </Button>
                    </div>
                    {caseItem.caseNumber && (
                      <div className="text-sm text-gray-500">
                        رقم القضية: {caseItem.caseNumber}
                      </div>
                    )}
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4 line-clamp-2">
                      {caseItem.description || "لا يوجد وصف"}
                    </p>
                    
                    <div className="flex items-center justify-between mb-4">
                      {getStatusBadge(caseItem.status)}
                      {getPriorityBadge(caseItem.priority)}
                    </div>

                    <div className="text-sm text-gray-500 space-y-1">
                      <div>تم الإنشاء: {new Date(caseItem.createdAt).toLocaleDateString('ar-YE')}</div>
                      {caseItem.nextHearingDate && (
                        <div>الجلسة القادمة: {new Date(caseItem.nextHearingDate).toLocaleDateString('ar-YE')}</div>
                      )}
                    </div>

                    <div className="flex justify-between items-center mt-4 pt-4 border-t">
                      <Button variant="outline" size="sm">
                        <i className="fas fa-eye ml-2"></i>
                        عرض
                      </Button>
                      <Button variant="outline" size="sm">
                        <i className="fas fa-edit ml-2"></i>
                        تحرير
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <i className="fas fa-folder-open text-gray-400 text-6xl mb-4"></i>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {searchQuery ? "لا توجد نتائج" : "لا توجد قضايا"}
                </h3>
                <p className="text-gray-600 mb-6">
                  {searchQuery 
                    ? `لا توجد قضايا تطابق البحث "${searchQuery}"`
                    : "لم تقم بإنشاء أي قضايا حتى الآن"
                  }
                </p>
                {!searchQuery && (
                  <Button 
                    onClick={() => setIsCreateDialogOpen(true)}
                    className="bg-primary-600 hover:bg-primary-700"
                  >
                    <i className="fas fa-plus ml-2"></i>
                    إنشاء قضية جديدة
                  </Button>
                )}
              </CardContent>
            </Card>
          )}

          {/* Statistics */}
          {filteredCases.length > 0 && (
            <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary-600">
                    {filteredCases.filter((c: any) => c.status === 'new' || c.status === 'under_review' || c.status === 'accepted' || c.status === 'in_progress').length}
                  </div>
                  <div className="text-sm text-gray-600">القضايا النشطة</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {filteredCases.filter((c: any) => c.status === 'completed').length}
                  </div>
                  <div className="text-sm text-gray-600">القضايا المكتملة</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {filteredCases.filter((c: any) => c.priority === 'high').length}
                  </div>
                  <div className="text-sm text-gray-600">أولوية عالية</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-gray-600">
                    {filteredCases.length}
                  </div>
                  <div className="text-sm text-gray-600">إجمالي القضايا</div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

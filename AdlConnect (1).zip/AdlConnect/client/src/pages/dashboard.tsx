import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import NavigationHeader from "@/components/navigation-header";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading, user } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "غير مخول",
        description: "تم تسجيل خروجك. جاري تسجيل الدخول مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Fetch recent cases
  const { data: cases, isLoading: casesLoading } = useQuery({
    queryKey: ["/api/cases"],
    retry: false,
    enabled: isAuthenticated,
  });

  if (authLoading || !isAuthenticated) {
    return <div className="min-h-screen bg-gray-50" />;
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      new: { label: "جديدة", variant: "default" as const },
      under_review: { label: "قيد المراجعة", variant: "secondary" as const },
      accepted: { label: "مقبولة", variant: "default" as const },
      in_progress: { label: "قيد التنفيذ", variant: "default" as const },
      completed: { label: "مكتملة", variant: "default" as const },
      closed: { label: "مغلقة", variant: "outline" as const },
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || { label: status, variant: "outline" as const };
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
  };

  const getCaseTypeIcon = (caseType: string) => {
    const iconMap = {
      'ملكية': 'fa-home',
      'تجاري': 'fa-handshake', 
      'إيجار': 'fa-key',
      'جنائي': 'fa-gavel',
      'إداري': 'fa-building',
      'مدني': 'fa-file-alt',
    };
    return iconMap[caseType as keyof typeof iconMap] || 'fa-file-alt';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-6">
          {/* Welcome Section */}
          <div className="gradient-bg rounded-xl p-6 text-white mb-8 card-shadow">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold mb-2">مرحباً بك في منصة القضاء الذكي</h2>
                <p className="text-blue-100 text-lg">إدارة شؤونك القانونية بكفاءة ودقة عالية</p>
                <div className="mt-4 flex space-x-reverse space-x-4">
                  <Button className="bg-white text-primary-700 px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                    <i className="fas fa-plus ml-2"></i>
                    قضية جديدة
                  </Button>
                  <Button variant="ghost" className="border border-white/30 text-white px-4 py-2 rounded-lg font-medium hover:bg-white/10 transition-colors">
                    <i className="fas fa-search ml-2"></i>
                    البحث السريع
                  </Button>
                </div>
              </div>
              <div className="hidden lg:block">
                <img 
                  src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=150" 
                  alt="مكتب قانوني محترف" 
                  className="rounded-lg shadow-lg w-48 h-32 object-cover"
                />
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="hover-lift transition-all duration-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-sm">القضايا النشطة</p>
                    {statsLoading ? (
                      <Skeleton className="h-8 w-16 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-gray-900">{stats?.activeCases || 0}</p>
                    )}
                  </div>
                  <div className="bg-primary-100 p-3 rounded-full">
                    <i className="fas fa-gavel text-primary-600 text-xl"></i>
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  <span className="text-green-600 font-medium">+12%</span>
                  <span className="text-gray-500 mr-2">عن الشهر الماضي</span>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift transition-all duration-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-sm">الوثائق المحفوظة</p>
                    {statsLoading ? (
                      <Skeleton className="h-8 w-16 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-gray-900">{stats?.documents || 0}</p>
                    )}
                  </div>
                  <div className="bg-secondary-100 p-3 rounded-full">
                    <i className="fas fa-folder text-secondary-600 text-xl"></i>
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  <span className="text-green-600 font-medium">+8%</span>
                  <span className="text-gray-500 mr-2">عن الشهر الماضي</span>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift transition-all duration-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-sm">العملاء المتابعون</p>
                    {statsLoading ? (
                      <Skeleton className="h-8 w-16 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-gray-900">{stats?.clients || 0}</p>
                    )}
                  </div>
                  <div className="bg-yellow-100 p-3 rounded-full">
                    <i className="fas fa-users text-yellow-600 text-xl"></i>
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  <span className="text-green-600 font-medium">+5%</span>
                  <span className="text-gray-500 mr-2">عن الشهر الماضي</span>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift transition-all duration-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-sm">الاستشارات المقدمة</p>
                    {statsLoading ? (
                      <Skeleton className="h-8 w-16 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-gray-900">{stats?.consultations || 0}</p>
                    )}
                  </div>
                  <div className="bg-purple-100 p-3 rounded-full">
                    <i className="fas fa-comments text-purple-600 text-xl"></i>
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  <span className="text-green-600 font-medium">+18%</span>
                  <span className="text-gray-500 mr-2">عن الشهر الماضي</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Cases */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader className="border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <CardTitle>القضايا الحديثة</CardTitle>
                    <Button variant="ghost" className="text-primary-600 hover:text-primary-700 text-sm font-medium">
                      عرض الكل
                      <i className="fas fa-arrow-left mr-1"></i>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  {casesLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="flex items-center space-x-reverse space-x-4 p-4">
                          <Skeleton className="w-10 h-10 rounded-full" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-3 w-1/2" />
                          </div>
                          <Skeleton className="h-6 w-16" />
                        </div>
                      ))}
                    </div>
                  ) : cases && cases.length > 0 ? (
                    <div className="space-y-4">
                      {cases.slice(0, 5).map((caseItem: any) => (
                        <div key={caseItem.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="flex items-center space-x-reverse space-x-4">
                            <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                              <i className={`fas ${getCaseTypeIcon(caseItem.caseType)} text-primary-600`}></i>
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{caseItem.title}</p>
                              <p className="text-sm text-gray-500">النوع: {caseItem.caseType}</p>
                              <p className="text-xs text-gray-400">
                                تم الإنشاء: {new Date(caseItem.createdAt).toLocaleDateString('ar-YE')}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-reverse space-x-2">
                            {getStatusBadge(caseItem.status)}
                            <Button variant="ghost" size="sm">
                              <i className="fas fa-ellipsis-h"></i>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <i className="fas fa-folder-open text-gray-400 text-4xl mb-4"></i>
                      <p className="text-gray-500">لا توجد قضايا حتى الآن</p>
                      <Button className="mt-4">
                        <i className="fas fa-plus ml-2"></i>
                        إنشاء قضية جديدة
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* AI Assistant & Quick Actions */}
            <div className="space-y-6">
              {/* AI Assistant */}
              <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl p-6 border border-purple-100">
                <div className="flex items-center space-x-reverse space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
                    <i className="fas fa-robot text-white"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">المساعد الذكي</h3>
                    <p className="text-sm text-gray-600">مدعوم بالذكاء الاصطناعي</p>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-4 mb-4">
                  <p className="text-sm text-gray-700 mb-3">ما هي الإجراءات المطلوبة لرفع دعوى ملكية عقارية؟</p>
                  <Button className="bg-primary-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary-700 transition-colors w-full">
                    <i className="fas fa-paper-plane ml-2"></i>
                    إرسال السؤال
                  </Button>
                </div>
                <p className="text-xs text-gray-500">اسأل عن أي موضوع قانوني وستحصل على إجابة مفصلة مع المراجع القانونية</p>
              </div>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>إجراءات سريعة</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button variant="ghost" className="w-full justify-start text-right">
                      <i className="fas fa-plus text-primary-600 ml-3"></i>
                      <span className="text-gray-700">إنشاء قضية جديدة</span>
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-right">
                      <i className="fas fa-file-upload text-secondary-600 ml-3"></i>
                      <span className="text-gray-700">رفع وثيقة</span>
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-right">
                      <i className="fas fa-search text-purple-600 ml-3"></i>
                      <span className="text-gray-700">البحث في القوانين</span>
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-right">
                      <i className="fas fa-file-contract text-orange-600 ml-3"></i>
                      <span className="text-gray-700">صياغة عقد</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Legal Resources Section */}
          <div className="mt-8">
            <Card>
              <CardHeader className="border-b border-gray-200">
                <CardTitle>الموارد القانونية</CardTitle>
                <p className="text-sm text-gray-600 mt-1">الوصول السريع للقوانين واللوائح والنماذج</p>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="group bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg hover:shadow-md transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-3">
                      <i className="fas fa-book text-blue-600 text-2xl"></i>
                      <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded-full">450+</span>
                    </div>
                    <h4 className="font-medium text-gray-900">القوانين اليمنية</h4>
                    <p className="text-sm text-gray-600 mt-1">مجموعة شاملة من القوانين واللوائح</p>
                  </div>

                  <div className="group bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg hover:shadow-md transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-3">
                      <i className="fas fa-file-contract text-green-600 text-2xl"></i>
                      <span className="bg-green-600 text-white text-xs px-2 py-1 rounded-full">120+</span>
                    </div>
                    <h4 className="font-medium text-gray-900">نماذج العقود</h4>
                    <p className="text-sm text-gray-600 mt-1">قوالب جاهزة قابلة للتعديل</p>
                  </div>

                  <div className="group bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg hover:shadow-md transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-3">
                      <i className="fas fa-gavel text-purple-600 text-2xl"></i>
                      <span className="bg-purple-600 text-white text-xs px-2 py-1 rounded-full">85+</span>
                    </div>
                    <h4 className="font-medium text-gray-900">نماذج الدعاوى</h4>
                    <p className="text-sm text-gray-600 mt-1">نماذج دعاوى قضائية متنوعة</p>
                  </div>

                  <div className="group bg-gradient-to-br from-orange-50 to-orange-100 p-4 rounded-lg hover:shadow-md transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-3">
                      <i className="fas fa-landmark text-orange-600 text-2xl"></i>
                      <span className="bg-orange-600 text-white text-xs px-2 py-1 rounded-full">200+</span>
                    </div>
                    <h4 className="font-medium text-gray-900">الأحكام القضائية</h4>
                    <p className="text-sm text-gray-600 mt-1">مرجع الأحكام والقرارات</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}

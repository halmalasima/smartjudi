import { sql, relations } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User roles enum
export const userRoleEnum = pgEnum("user_role", [
  "lawyer",
  "legal_secretary", 
  "client",
  "trainee",
  "admin"
]);

// Case status enum
export const caseStatusEnum = pgEnum("case_status", [
  "new",
  "under_review",
  "accepted",
  "in_progress",
  "completed",
  "closed"
]);

// Document type enum
export const documentTypeEnum = pgEnum("document_type", [
  "contract",
  "lawsuit",
  "court_document",
  "legal_opinion",
  "evidence",
  "other"
]);

// Users table - required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").default("client"),
  specialization: text("specialization"), // For lawyers
  licenseNumber: varchar("license_number"), // For lawyers
  phone: varchar("phone"),
  address: text("address"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Courts table
export const courts = pgTable("courts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: varchar("type"), // مدني، جنائي، تجاري، إداري
  address: text("address"),
  phone: varchar("phone"),
  email: varchar("email"),
  city: varchar("city"),
  governorate: varchar("governorate"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Legal cases table
export const cases = pgTable("cases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  caseType: varchar("case_type"), // ملكية، تجاري، إيجار، جنائي
  status: caseStatusEnum("status").default("new"),
  clientId: varchar("client_id").references(() => users.id),
  lawyerId: varchar("lawyer_id").references(() => users.id),
  courtId: varchar("court_id").references(() => courts.id),
  caseNumber: varchar("case_number"),
  filingDate: timestamp("filing_date"),
  nextHearingDate: timestamp("next_hearing_date"),
  priority: varchar("priority").default("medium"), // high, medium, low
  estimatedValue: integer("estimated_value"), // القيمة المالية للقضية
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Documents table
export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  type: documentTypeEnum("type").notNull(),
  filePath: text("file_path"),
  fileName: text("file_name"),
  fileSize: integer("file_size"),
  mimeType: varchar("mime_type"),
  caseId: varchar("case_id").references(() => cases.id),
  uploadedById: varchar("uploaded_by_id").references(() => users.id),
  isTemplate: boolean("is_template").default(false),
  templateCategory: varchar("template_category"), // عقود، دعاوى، etc.
  tags: text("tags").array(), // للبحث والتصنيف
  content: text("content"), // محتوى النص للبحث
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Laws and regulations table
export const laws = pgTable("laws", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  number: varchar("number"), // رقم القانون
  year: integer("year"),
  category: varchar("category"), // مدني، تجاري، جنائي، إداري
  content: text("content").notNull(),
  summary: text("summary"),
  keywords: text("keywords").array(),
  isActive: boolean("is_active").default(true),
  publishedDate: timestamp("published_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Subscription plans table
export const subscriptionPlans = pgTable("subscription_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // خطة المحامي الأساسية، الأمين الشرعي المتقدمة
  nameEn: text("name_en").notNull(),
  description: text("description"),
  descriptionEn: text("description_en"),
  price: integer("price").notNull(), // في الريال اليمني
  duration: integer("duration").notNull(), // بالأيام
  userRole: userRoleEnum("user_role").notNull(),
  features: jsonb("features").notNull(), // قائمة الميزات والحدود
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User subscriptions table
export const userSubscriptions = pgTable("user_subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  planId: varchar("plan_id").references(() => subscriptionPlans.id),
  startDate: timestamp("start_date").defaultNow(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(true),
  paymentStatus: varchar("payment_status").default("pending"), // pending, paid, failed
  features: jsonb("features"), // نسخة مخزنة من الميزات لهذا الاشتراك
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Government services integration table
export const governmentServices = pgTable("government_services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  nameEn: text("name_en").notNull(),
  description: text("description"),
  ministry: varchar("ministry"), // وزارة العدل، الداخلية، etc.
  serviceType: varchar("service_type"), // lawsuit_filing, inquiry, complaint
  endpoint: text("endpoint"), // API endpoint
  isActive: boolean("is_active").default(true),
  requiredFields: jsonb("required_fields"), // الحقول المطلوبة
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Service requests table
export const serviceRequests = pgTable("service_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  serviceId: varchar("service_id").references(() => governmentServices.id),
  caseId: varchar("case_id").references(() => cases.id),
  requestData: jsonb("request_data").notNull(),
  status: varchar("status").default("pending"), // pending, submitted, completed, failed
  referenceNumber: varchar("reference_number"),
  response: jsonb("response"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Professional ratings and reviews
export const professionalReviews = pgTable("professional_reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reviewerId: varchar("reviewer_id").references(() => users.id),
  professionalId: varchar("professional_id").references(() => users.id),
  caseId: varchar("case_id").references(() => cases.id),
  rating: integer("rating").notNull(), // 1-5
  review: text("review"),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Legal secretary services specific to Islamic law
export const shariaServices = pgTable("sharia_services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: varchar("category"), // inheritance, marriage, divorce, financial
  requiredDocuments: text("required_documents").array(),
  estimatedDuration: varchar("estimated_duration"),
  fees: integer("fees"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI assistant conversations
export const aiConversations = pgTable("ai_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  question: text("question").notNull(),
  response: text("response").notNull(),
  context: jsonb("context"), // Additional context for the AI
  relatedLaws: text("related_laws").array(), // IDs of related laws
  relatedCases: text("related_cases").array(), // IDs of related cases
  rating: integer("rating"), // User feedback 1-5
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  clientCases: many(cases, { relationName: "clientCases" }),
  lawyerCases: many(cases, { relationName: "lawyerCases" }),
  documents: many(documents),
  conversations: many(aiConversations),
}));

export const casesRelations = relations(cases, ({ one, many }) => ({
  client: one(users, {
    fields: [cases.clientId],
    references: [users.id],
    relationName: "clientCases",
  }),
  lawyer: one(users, {
    fields: [cases.lawyerId],
    references: [users.id],
    relationName: "lawyerCases",
  }),
  court: one(courts, {
    fields: [cases.courtId],
    references: [courts.id],
  }),
  documents: many(documents),
}));

export const documentsRelations = relations(documents, ({ one }) => ({
  case: one(cases, {
    fields: [documents.caseId],
    references: [cases.id],
  }),
  uploadedBy: one(users, {
    fields: [documents.uploadedById],
    references: [users.id],
  }),
}));

export const courtsRelations = relations(courts, ({ many }) => ({
  cases: many(cases),
}));

export const lawsRelations = relations(laws, ({ many }) => ({
  // Add any relations if needed
}));

export const aiConversationsRelations = relations(aiConversations, ({ one }) => ({
  user: one(users, {
    fields: [aiConversations.userId],
    references: [users.id],
  }),
}));

export const subscriptionPlansRelations = relations(subscriptionPlans, ({ many }) => ({
  subscriptions: many(userSubscriptions),
}));

export const userSubscriptionsRelations = relations(userSubscriptions, ({ one }) => ({
  user: one(users, {
    fields: [userSubscriptions.userId],
    references: [users.id],
  }),
  plan: one(subscriptionPlans, {
    fields: [userSubscriptions.planId],
    references: [subscriptionPlans.id],
  }),
}));

export const governmentServicesRelations = relations(governmentServices, ({ many }) => ({
  requests: many(serviceRequests),
}));

export const serviceRequestsRelations = relations(serviceRequests, ({ one }) => ({
  user: one(users, {
    fields: [serviceRequests.userId],
    references: [users.id],
  }),
  service: one(governmentServices, {
    fields: [serviceRequests.serviceId],
    references: [governmentServices.id],
  }),
  case: one(cases, {
    fields: [serviceRequests.caseId],
    references: [cases.id],
  }),
}));

export const professionalReviewsRelations = relations(professionalReviews, ({ one }) => ({
  reviewer: one(users, {
    fields: [professionalReviews.reviewerId],
    references: [users.id],
    relationName: "reviewerRelation",
  }),
  professional: one(users, {
    fields: [professionalReviews.professionalId],
    references: [users.id],
    relationName: "professionalRelation",
  }),
  case: one(cases, {
    fields: [professionalReviews.caseId],
    references: [cases.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCaseSchema = createInsertSchema(cases).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLawSchema = createInsertSchema(laws).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCourtSchema = createInsertSchema(courts).omit({
  id: true,
  createdAt: true,
});

export const insertAiConversationSchema = createInsertSchema(aiConversations).omit({
  id: true,
  createdAt: true,
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSubscriptionSchema = createInsertSchema(userSubscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertGovernmentServiceSchema = createInsertSchema(governmentServices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertServiceRequestSchema = createInsertSchema(serviceRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProfessionalReviewSchema = createInsertSchema(professionalReviews).omit({
  id: true,
  createdAt: true,
});

export const insertShariaServiceSchema = createInsertSchema(shariaServices).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Case = typeof cases.$inferSelect;
export type InsertCase = z.infer<typeof insertCaseSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type Law = typeof laws.$inferSelect;
export type InsertLaw = z.infer<typeof insertLawSchema>;

export type Court = typeof courts.$inferSelect;
export type InsertCourt = z.infer<typeof insertCourtSchema>;

export type AiConversation = typeof aiConversations.$inferSelect;
export type InsertAiConversation = z.infer<typeof insertAiConversationSchema>;

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;

export type UserSubscription = typeof userSubscriptions.$inferSelect;
export type InsertUserSubscription = z.infer<typeof insertUserSubscriptionSchema>;

export type GovernmentService = typeof governmentServices.$inferSelect;
export type InsertGovernmentService = z.infer<typeof insertGovernmentServiceSchema>;

export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type InsertServiceRequest = z.infer<typeof insertServiceRequestSchema>;

export type ProfessionalReview = typeof professionalReviews.$inferSelect;
export type InsertProfessionalReview = z.infer<typeof insertProfessionalReviewSchema>;

export type ShariaService = typeof shariaServices.$inferSelect;
export type InsertShariaService = z.infer<typeof insertShariaServiceSchema>;
